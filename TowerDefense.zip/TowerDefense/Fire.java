import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The fire class is a subclass of the bullet class. Its speed is normal and is a type of elemental 
 * bullet. It is only used by the fire towers.
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class Fire extends Bullet
{

    /**
     * the constructor for the fire class
     * 
     * @param t the mob that this bullet is aiming at
     */
    public Fire(Actor t,int dmg)
    {
        damage = dmg;
        this.target = t;
        this.speed = 20;
        this.type = "fire";
        s = new GreenfootSound ("fire.wav");
    }

    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //plays the sound effect
        s.play();
        //moves the bullet
        move(speed);
        //checks if the bullet is at the worlds edge
        atWorldEdge();

    }
    
        /**
     * overrides the addedToWorld method in the actor super class and makes sure that as the bullet spawns it
     * turns towards the target
     * 
     * @param w gets the world
     */
    public void addedToWorld (World w)
    {
        turnTowards(target.getX(),target.getY());
    }
}