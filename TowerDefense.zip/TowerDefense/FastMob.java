import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Fast mobs are the quickest mobs in the game , however they have low hp and are weak
 * 
 * @author Yao Lu, Ryan Lau, Natalie Lee
 * @version Jan 2014
 */
public class FastMob extends Mobs
{
    /**
     * Construction defines detailed basic info of the mob
     * 
     * @param speed The speed of the mob
     * @param health Health Point of the mob
     * @param Defense Defense of the mob
     * @param Type of the mob
     */ 
    public FastMob(int speed, int health, int defense,String type)
    {
        this.speed=speed;
        this.health = health;
        this.defense = defense;
        this.type = type;
        this.name = "fast";
        //the type of the mob decides which image to use
        if (type == "normal")
        {
            setImage("Umbreon.png");   
        }
        else if (type == "fire")
        {
            setImage("Ninetales.png");
        }
        else if (type == "water")
        {
            setImage("Starmie.png");
        }
        else if (type == "earth")
        {
            setImage("Rhyhorn.png");
        }
        else if (type == "wood")
        {
            setImage("Ninjask.png");
        }
        else if (type == "metal")
        {
            setImage("Steelix.png");
        }
    } 

     public void act() 
    {
        //adds a health bar for the mob
        if (healthBar == null){
            healthBar = new HealthBar(45,8,6,health,health);
            getWorld().addObject(healthBar, getX(), getY()-20);
        }else{
            //once added, the health bar is updated throughout the game 
            //so that it follows the mob
            healthBar.setLocation(this.getX(),this.getY()-20);  
        }
                ifClicked();
        checkBullet();
        moveAlongPath(speed);
    }
}
