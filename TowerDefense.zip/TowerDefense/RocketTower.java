import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the rocket tower is the slowest shooting tower but it is very strong. There are 5 upgrades for this tower in total
 * 
 * @author Natalie Lee, Ahsen Husain
 * @version Jan 2014
 */
public class RocketTower extends Towers
{
    private int counter =0;
    /**
     * constructor for the rocket tower
     * 
     * @param ID the ID of this tower
     */
    public RocketTower(int ID)
    {
        this.ID = ID;
        this.level = 1;
        this.range = 80;
        this.name = "rocket";
        this.damage = 10;
        this.cost = 50;
        this.info = "Damage:25 \nRange:90 \nCost: $50 \nSpeed: Slow";
        this.type = "rocket";
    }

    /**
     * Act - do whatever the AOETower wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //prevents the tower from shooting too quickly
        counter++;
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        myWorld m = (myWorld)getWorld();
        MouseInfo mouse = Greenfoot.getMouseInfo();
        //checks the mouse
        if (Greenfoot.mouseClicked(this))
        {
            //if this tower is clicked it will give the player the option to sell or upgrade the tower
            m.infoHold(type,ID, info,level,name);
            m.createTowerOptionButton("upgrade",this.getX(),this.getY(),type);
            if (this.level<5)
            {

                i.update(name,info);
            }
        }

        //every 5 acts the tower will check for a target
        if (counter == 30)
        {
            counter = 0;
            checkTarget(type);
        }
    }

}
