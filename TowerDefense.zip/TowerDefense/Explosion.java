import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the explosion class is a special type of bullet that appears after the rocket bullet has hit its target
 * 
 * @author Natalie Lee 
 * @version Jan 2014
 */
public class Explosion extends Bullet
{
    private int counter=0;
    
    /**
     * the constructor for the explosion class
     */
    public Explosion(int dmg)
    {
        damage = dmg;
        this.type = "rocket";
    }
    /**
     * Act - do whatever the Explosion wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        myWorld m = (myWorld)getWorld();
        updateImage();
        counter++;
        //after the animation is finished the object is removed
        if (counter >9)
        {
            m.removeObject(this);
        }
    }    
    
    /**
     * the animation for the explosion class
     */
    private void updateImage()
    {
        if (counter ==0)
        {
            setImage("ex1.png");
        }
        else if (counter ==1)
        {
            setImage("ex2.png");
        }
        else if (counter ==2)
        {
            setImage("ex3.png");
        }
        else if (counter ==3)
        {
            setImage("ex4.png");
        }
        else if (counter ==4)
        {
            setImage("ex5.png");
        }
        else if (counter ==5)
        {
            setImage("ex6.png");
        }
        else if (counter ==6)
        {
            setImage("ex7.png");
        }
        else if (counter ==7)
        {
            setImage("ex8.png");
        }
        else if (counter ==8)
        {
            setImage("ex9.png");
        }
        else if (counter ==9)
        {
            setImage("ex10.png");
        }
    }
}
