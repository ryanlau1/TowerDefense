import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the laser tower is the quickest shooting tower but it is very weak. There are 5 upgrades for this tower in total
 * 
 * @author Natalie Lee, Ahsen Husain
 * @version Jan 2014
 */
public class LaserTower extends Towers
{
    private int counter=0;   
    /**
     * constructor for the laser tower
     * 
     * @param ID the ID of this tower
     */
    public LaserTower(int ID)
    {
        this.ID = ID;
        this.level = 1;
        this.range = 100;
        this.info = "Damage:5 \nRange:120 \nCost: $30 \nSpeed: Fast";
        this.name = "laser";
        this.damage = 2;
        this.cost = 30;
        this.type ="laser";
    }

    /**
     * Act - do whatever the LaserTower wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //prevents the tower from shooting too quickly
        counter++;
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        myWorld m = (myWorld)getWorld();
        MouseInfo mouse = Greenfoot.getMouseInfo();

        //checks the mouse
        if (Greenfoot.mouseClicked(this))
        {
            //if this tower is clicked it will give the player the option to sell or upgrade the tower
            m.infoHold(type,ID, info,level, name);

                m.createTowerOptionButton("upgrade",this.getX(),this.getY(),type);
            if (this.level<5)
            {
                i.update(name,info);
            }
        }

        //every 5 acts the tower will check for a target
        if (counter == 5 )
        {
            counter =0;
            checkTarget(type);
        }
    }    

}
