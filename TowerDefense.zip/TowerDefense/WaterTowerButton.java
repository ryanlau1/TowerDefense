import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the water tower button creates a new water tower 
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class WaterTowerButton extends Buttons
{
    /**
     * the constructor for the water tower button
     */
    public WaterTowerButton()
    {
        image = new GreenfootImage("watertowerbutton.png");
        setImage(image);
    }

    /**
     * Act - do whatever the WaterTowerButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
 
        myWorld m = (myWorld)getWorld();
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        //checks for the mouse
        if (Greenfoot.mouseMoved(this))
        {
            //updates info
            updateImage("watertowerbutton");
            i.update("Damage:100 \nRange:130 \nCost: $170 \nSpeed: Normal");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("watertowerbutton");
        }
        else if (Greenfoot.mouseClicked(this))
        {
            //removes the previous tower if the player can build this tower
                        if (m.getMoney() >=170)
            {
                m.removeTower();
            }
            m.createTower("water");

        }

    }    
}
