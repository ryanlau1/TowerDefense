import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The back button is found in the instructions page and if clicked, lets the player return to the previous instructions
 * page or to go back to the main menu
 * 
 * @author Amanda Mak, Natalie Lee 
 * @version Jan 2014
 */
public class BackButton extends Buttons
{
    /**
     * Act - do whatever the BackButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        //checks for the mouse
        if (Greenfoot.mouseMoved(this))
        {
            updateImage("BackButton");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("BackButton");
        }
    }    
}
