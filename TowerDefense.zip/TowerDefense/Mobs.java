import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Mobs is a class that serves as the super class of several specific types of mob classes. 
 * <p>
 * Basic functions such as moving along the path and checking the bullets are defined in this class. 
 * Other methods include getting the ID and name of the mob, which assist the world class in determining
 * how much money is earned every time a mob is killed.  
 * 
 * @Yao Lu, Natalie Lee, Ryan Lau
 * @version 1
 */
public abstract class Mobs extends Actor
{
    //initializes the basic info of a mob
    protected int speed, defense,ID, health;
    protected String name;
    protected String type;
    //shouldDie keeps track of the mob's health and location. Checked at the end of the act method.
    protected boolean shouldDie; 
    //leaked distingulishes mobs leaded into the tower from the mobs killed when removing them from the world
    protected boolean leaked;    
    //helps the mob moving along the path
    private turnPoint next;
    private boolean onTurnPoint;
    //a health bar that follows the mob
    protected HealthBar healthBar;
    private int reducedHealth;

    /**
     * Construction defines the common basic info of mobs
     */
    public Mobs(){    
        shouldDie = false;   
        leaked = false;
    }

    /**
     * Checks the health point of the mob and decides if it should be removed
     */
    protected void checkDead()
    {
        if (health <= 0)
        {
            if (this != null)
            {
                getWorld().removeObject(this);
            }
        }
    }

    /**
     * Decreases the health point when the mob meets a bullet
     */
    protected void checkBullet()
    {
        Bullet b= (Bullet)getOneIntersectingObject(Bullet.class);
        Rocket r= (Rocket)getOneIntersectingObject(Rocket.class);
        myWorld world = (myWorld)getWorld();

        //when the mob touches a bullet, the health decreases, 
        //at the same time, the bullet is removed from the world
        if(b!=null){ 
            //adds special animation effect for rocket bullets
            if(r!=null)
            {
                world.addExplosion(this.getX(),this.getY(),b.getDamage());
            }
            checkElement(b.getType(), this.getType(), b.getDamage(),this.getName());
            world.removeObject(b);
        }
        //if health is not positive, the mob should die
        if(health <= 0){
            shouldDie = true;
        }                
    }

    /**
     * Decreases the health point by a certain amount
     * 
     * @param i The amount of health that needs to be decreased
     */
    protected void decHealth(int i){
        health -= i;
    }

    /**
     * Leads the mob to move along the path in the world using turn points.
     * 
     * @param s The speed of the mob
     */
    protected void moveAlongPath(int s){
        //turn points are set at the cornors of the path, and connected in the order that the mobs will pass them.
        //They serve as the targets that the mobs move towards. 

        if (getOneIntersectingObject(turnPoint.class) != null){    
            //defines current turnPoint as the one at location
            turnPoint current = (turnPoint)getOneIntersectingObject(turnPoint.class);   

            //defines the next turnPoint (target) as itself if the code is run for the first time
            if(next == null) {
                next = current;                
            }   

            //checks again if this turnPoint that the mob is touching is the target, if true, then defines a new one
            if(next == current) {
                //defines the target
                next = current.getNextTurnPoint(); 
                //turns towards the target
                setLocation(current.getX(), current.getY());
                turnTowards(next.getX(),next.getY());             
            }                
        }        
        move(s);

        //removes the mob if it has reached the last turnPoint, which is the end point
        EndPoint e = (EndPoint)getOneIntersectingObject(EndPoint.class);
        myWorld world = (myWorld)getWorld();
        if (e!=null)
        {
            shouldDie = true;
            leaked = true;
            world.removeLife(this.getName());
        }

        //removes the mob as well as its health barif it should die
        if(shouldDie){
            //if the mob is removed beacuse it has reached the end point, then money is not given to the player
            if (leaked == false)
            {
                world.getMoney(this.getName());
            }
            world.removeObject(this.healthBar);
            world.removeObject(this);
        }
    } 

    /**
     * Returns the ID of the mob
     * 
     * @return ID mob ID
     */
    protected int getID()
    {
        return ID;
    }

    /**
     * returns the type of the mob
     * 
     * @return String The elemental type of the mob 
     */
    protected String getType()
    {
        return type;
    }

    /**
     * return the name of the mob
     * 
     * @return String the name of the mob
     */
    protected String getName()
    {
        return name;
    }

    /**
     *  reduces the damage taken based on the defense of the mob
     *  
     *  @param damage the damage that the tower dealt
     */
    protected void takePhysDamage(int damage)
    {
        //Resist 4 percent for every defense point
        double resistedDamage = (defense * 4)*0.01;

        //Lose health equal to percent of the damage
        health -= damage * (1-resistedDamage);
        reducedHealth = (int)(damage * (1-resistedDamage));
    }

    /**
     * checks the element of both the mob and the bullets and manipulates the damage dealt by the bullet 
     * 
     * @param bulletElement  the element of the bullet
     * @param mobElement     the element of the mob
     * @param dmg            the damage the bullet deals
     * @param name           the name of the mob
     */
    protected void checkElement(String bulletElement, String mobElement, int dmg, String name)
    {
        //the element system
        //fire beats wood and metal
        //water beats fire and metal
        //wood beats water and earth
        //earth beats fire and water
        //metal beats earth and wood

        //when a certain element beats another the damage dealt is multiplied by 2
        //when a certain element is beat by another the damage dealt is halved
        if (mobElement.equals("fire"))
        {
            if (bulletElement.equals("wood") || bulletElement.equals("metal"))
            {
                dmg = dmg/2;
            }
            else if (bulletElement.equals("earth") || bulletElement.equals("water"))
            {
                dmg = dmg*2;
            }
        }
        else if (mobElement.equals("water"))
        {
            if (bulletElement.equals("metal") || bulletElement.equals("fire"))
            {
                dmg = dmg/2;
            }
            else if (bulletElement.equals("wood") || bulletElement.equals("earth"))
            {
                dmg = dmg*2;
            }
        }
        else if (mobElement.equals("wood"))
        {
            if (bulletElement.equals("water") || bulletElement.equals("earth"))
            {
                dmg = dmg/2;
            }
            else if (bulletElement.equals("fire") || bulletElement.equals("metal"))
            {
                dmg = dmg*2;
            }
        }
        else if (mobElement.equals("earth"))
        {
            if (bulletElement.equals("fire") || bulletElement.equals("water"))
            {
                dmg = dmg/2;
            }
            else if (bulletElement.equals("metal") || bulletElement.equals("wood"))
            {
                dmg = dmg*2;
            }
        }
        else if (mobElement.equals("metal"))
        {
            if (bulletElement.equals("earth") || bulletElement.equals("wood"))
            {
                dmg = dmg/2;
            }
            else if (bulletElement.equals("fire") || bulletElement.equals("water"))
            {
                dmg = dmg*2;
            }
        }
        else if (mobElement.equals("metal") && name.equals("normal"))
        {
            if (bulletElement!="normal")
            {
                dmg = dmg/5;
            }
        }

        //decreases the health
        takePhysDamage(dmg);
        this.healthBar.decValue(reducedHealth);

    }

    /**
     * if a mob was clicked then it erases the worlds temporary info it holds
     */
    protected void ifClicked()
    {
        myWorld m = (myWorld)getWorld();
        // Add your action code here.
        if (Greenfoot.mouseClicked(this))
        {
            m.clearTemp();
        }
    }

}

