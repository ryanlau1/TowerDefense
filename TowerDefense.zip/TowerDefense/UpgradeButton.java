import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * If this buton was clicked then the user upgrades the tower than was selected
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class UpgradeButton extends Buttons
{
    /**
     * the constructor for the upgradebutton class
     */
    public UpgradeButton()
    {
        image = new GreenfootImage("upgrade.png");
        setImage(image);
    }

    /**
     * Act - do whatever the UpgradeButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //checks for the mouse
        myWorld m = (myWorld)getWorld();
        if (Greenfoot.mouseMoved(this))
        {
            updateImage("upgrade");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("upgrade");
        }
        else if (Greenfoot.mouseClicked(this))
        {
            m.upgradeTower();
        }
    }    
}
