import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
//Import for setting the image of this actor
import java.awt.Color;
//Imports for reading the file
import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
/**
 * Allows the player to see the 5 most recent scores from other players.
 * 
 * @author Amanda Mak
 * @version Jan 2014
 */
public class showScore extends Actor
{
    private ArrayList<String> highScores;
    private String[] recentScores = new String[6];
    private Scanner scan;
    /**
     * Act - do whatever the showScore wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    /**
     * Constructor for the class. 
     */
    public showScore()
    {
        getHighScores();
        //Assigns the 5 most recent scores to an image
        setImage(new GreenfootImage(recentScores[1] + "\n" + recentScores[2] + "\n" + recentScores[3] + "\n" + recentScores[4]+ "\n" + recentScores[5], 40, Color.WHITE, null));
    }
    /**
     * Reads the high scores from a file and assigns them to an array that will be outputted onto the screen
     */
    private void getHighScores()
    {
        highScores = new ArrayList<String>();
        //Tries to scan the file while it has a next line.
        try
        {
            scan = new Scanner(new File("High_Scores.txt"));
            while (scan.hasNext())
            {
                highScores.add(scan.nextLine());
            }
        }
        //Catches the exception
        catch (Exception e)
        {
            System.out.println("File not found");
        }
        //Closes the scanner if it is not null, will be performed at the very end
        finally
        {
            if (scan!=null)
            {
                scan.close();
            }
        }
        //scoreNum is used to keep track of the size
        int scoreNum = highScores.size();
        
        //Assigns the 5 most recent scores to an array
        for (int j = 1; j < 6; j++)
        {
            recentScores[j] = highScores.get(scoreNum-j);
        }
    }
}
