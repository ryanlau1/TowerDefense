import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;  
// for Scanning
import java.util.Scanner;
import java.util.ArrayList;
import java.util.NoSuchElementException;
// for Files
import java.io.File;
import java.io.FileNotFoundException;   
//jave swing
import javax.swing.JOptionPane;
/**
 * <><><><><+[About The Game]+><><><><>
 * 
 * Raayn Tower defense is a survival tower defense game that involves strategy and some quick reflexes. The game relies heavily on the 2d array 
 * which it uses through importing it from a file. Like every tower defense game the main objective is to defend your castle from advancing waves
 * of enemies using towers. The maine interaction system it uses, is the infopanel which provides the player information on 
 * their own status as well as information on the tower they can build and the ability to build those towers. the purpose of the game is not to beat 
 * a certain amount of level, but to get the highest score which is determined by the type of mob that was killed. The user can interact with the world 
 * after they press the start button. Once the user presses the start button they will encounter an endless wave of mobs that slowly get stronger as the 
 * levels increase. The first four waves of mobs are preset as normal, fast, slow, and flying in that order. Then every wave after that is a random 
 * amount of each mob. Every 10 waves a boss is spawned and takes 5 lives if it is not killed
 * 
 * 
 * 
 * <><><><><+[How To Play]+><><><><>
 * 
 * You get to see how much money you have, how many lives you have, what level you are on and what your score is. 
 * You can click on a tile to build an arrow, a rocket or a laser tower if you have the money.
 * You can upgrade these three basic towers five times.
 * After the fifth upgrade an arrow tower can turn into a water or wood tower.
 * After the fifth upgrade a rocket tower can turn into a fire or earth tower.
 * After the fifth upgrade a laser tower can turn into a metal tower.
 * Elemental towers are expensive but do more damage.
 * If the the tower element beats a mob element it does 2x damage
 * If the elements match the tower does neutral damage which is 1x damage.
 * If the tower element is resisted the mob takes 0.5x damage. These would be the remaining two elements.
 * 
 * MOBS
 * 
 * normal -the most basic mob with average health, speed and defense
 * slow   -the most powerful mob with high health and defense by low speed
 * fast   -the quickest mob with high speed but low defense and health
 * flying -the above average mob with above average health, speed and defense
 * boss   -the boss has high health, defense and average speed
 * 
 * TOWERS
 * 
 * arrow  -a basic tower with average damage and speed and 5 upgrades. The arrow tower is one of the three original towers to be built in the beginning of the game.
 * rocket -a tower with high damage but low speed and 5 upgrades. The rocket tower is one of the three original towers to be built in the beginning of the game.
 * laser  -a tower with high speed but low damage and 5 upgrades. The laser tower is one of the three original towers to be built in the beginning of the game.
 * fire   -high damage with low speed and cannot upgrade.
 * water  -above average damage with average speed and cannot upgrade.
 * wood   -above average damage with average speed and cannot upgrade.
 * metal  -high damage with low speed and cannot upgrade.
 * earth  -low damage with high speed and cannot upgrade.
 * 
 * THE ELEMENT SYSTEM
 * fire beats wood and metal
 * water beats fire and metal
 * wood beats water and earth
 * earth beats fire and water
 * metal beats earth and wood
 * 
 * 
 * 
 * <><><><><+[Notes and Credits]+><><><><>
 * 
 * -the sound effect for the wood bullet doesn seem to work on my (Natalie) computer and gives the error of not being able to play it because ofmy sound system
 * but it has worked on other teammates computers.
 * -once there are alot of towers the game could get really laggy
 * -sometimes when there too many different updates in the infopanel it kinda breaks down on you
 * 
 * music credits :https://soundcloud.com/groups/movie-game-background-music-soundtrack-music
 * https://www.facebook.com/l.php?u=http%3A%2F%2Fsoundbible.com%2Ftags-water-drop.html&h=vAQE5D5xs
 * 
 * picture credits:
 * 
 * towers and bullets
 * http://liubavyshka.ru/_ph/26/2/113067449.gif
 * http://th09.deviantart.net/fs71/150/f/2010/235/a/6/Pixel_Art__Castle_Keep_by_DoctorDRG.png
 * http://fc06.deviantart.net/fs71/f/2011/330/e/4/the_pixel_tower_of_babel_by_atskaheart-d4hffz4.png
 * http://www.ludumdare.com/compo/wp-content/uploads/2012/08/sprite-rocks.jpg
 * http://www.tutoriallounge.com/wp-content/uploads/Animate-a-Cartoon-Explosion-With-Flash-Professional-Basix.jpg
 * http://img.ios.d.cn/Upload/Editor/2013/4/20130424092952_1406.jpg
 * http://opengameart.org/sites/default/files/styles/watermarked/public/styles/thumbnail/public/WaterFountain.gif
 * 
 * mobs
 * www.serebii.net
 * 
 * @author Amanda Mak, Natalie Lee, Yao Lu, Ryan Lau, Ahsen Husain
 * @version Jan 2014
 */
public class myWorld extends World
{
    /** 
     * Declaring variables for the different cells that will make up the world.
     * BuildableCell - The cell that the player can build their towers on
     * PathCell - The cell that the mobs can walk on
     * turnPoint - The mobs require a turn point in order to move through the different paths
     * EndPoint - The 'end'. If mobs reach the end of the path, the player loses a life.
     */
    private BuildableCell[] buildable = new BuildableCell[400];
    private PathCell[] path = new PathCell [100];
    private turnPoint[] turnpoint = new turnPoint[20];
    private EndPoint endpoint = new EndPoint();
    /**
     * Variables that let the user change which map they want to use.
     * fileName - The name of the file they will be using
     * mapFile - The Array to hold all the lines of the file
     * map - Characters are required to read through each individual character in the lines of the file
     */
    private String fileName = "map2";
    private Scanner scan;
    private String[] mapFile = new String[20];
    private char[][]map = new char[20][20];;

    private int buildX;
    private int buildY;

    //variables for spawning mobs
    private int spawnX;
    private int spawnY;
    private int numOfFastMobs;
    private int numOfNormalMobs;
    private int numOfSlowMobs;
    private int numOfFlyingMobs;
    private int totalNumOfMobs;
    private int mobID=0;
    private boolean finishedWave=true;
    private boolean start = false;
    private boolean levelUp = true;
    private int ranType;
    private String mobType;

    //user information
    private int money = 2000;
    private int score =0;
    private int level=1 ;

    /**
     * Variables that keep track of how many lives the user has. 
     * Lives - An array for the different hearts that the player can use to visually track how many lives there are
     * full/empty Heart - Different pictures; full heart is for the lives they still have. empty heart is for the 
     * lives that they have lost so far
     */
    private Lives[] lives = new Lives[20];
    private GreenfootImage fullHeart = new GreenfootImage("life.png");
    private GreenfootImage emptyHeart = new GreenfootImage("no_life.png");
    private int numLives = 20;

    private infoPanel info = new infoPanel(money,level,numLives,score);
    private MouseInfo m = Greenfoot.getMouseInfo();

    //arraylists of towers
    private ArrayList<ArrowTower> arrowTowers = new ArrayList<ArrowTower>();
    private ArrayList<RocketTower> rocketTowers = new ArrayList<RocketTower>();
    private ArrayList<LaserTower> laserTowers = new ArrayList<LaserTower>();
    private ArrayList<MetalTower> metalTowers = new ArrayList<MetalTower>();
    private ArrayList<FireTower> fireTowers = new ArrayList<FireTower>();
    private ArrayList<WaterTower> waterTowers = new ArrayList<WaterTower>();    
    private ArrayList<WoodTower> woodTowers = new ArrayList<WoodTower>();
    private ArrayList<EarthTower> earthTowers = new ArrayList<EarthTower>();

    //declaring buttons
    private ArrowTowerButton arrowTowerButton = new ArrowTowerButton();
    private RocketTowerButton rocketTowerButton = new RocketTowerButton();
    private LaserTowerButton laserTowerButton = new LaserTowerButton();  
    private FireTowerButton fireTowerButton = new FireTowerButton();
    private WaterTowerButton waterTowerButton = new WaterTowerButton();
    private WoodTowerButton woodTowerButton = new WoodTowerButton();
    private MetalTowerButton metalTowerButton = new MetalTowerButton();
    private EarthTowerButton earthTowerButton = new EarthTowerButton();
    private SellButton sellButton = new SellButton();
    private UpgradeButton upgradeButton = new UpgradeButton();
    private StartWaveButton startWaveButton = new StartWaveButton();

    private ArrayList<Mobs> wave = new ArrayList<Mobs>();

    //variables that count the spawn number for mobs
    private int numOfArrowTowers=0;
    private int numOfLaserTowers=0;
    private int numOfRocketTowers=0;
    private int numOfFireTowers=0;
    private int numOfWaterTowers=0;
    private int numOfMetalTowers=0;
    private int numOfEarthTowers=0;
    private int numOfWoodTowers=0;

    //hold temporary information
    private int tempID;
    private String tempInfo = "";
    private String tempTower = "";
    private int tempLevel;
    private String tempName = "";
    private int counter =0;
    private int mobsToSpawn = 0;

    private Mobs mob;

    private String pName = "Player";
    private String s;
    //music
    GreenfootSound background;
    GreenfootSound death;

    /**
     * Constructor for objects of class myWorld.
     * 
     */
    public myWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        background = new GreenfootSound ("background.mp3");
        death = new GreenfootSound ("death.wav");

        addObject(info,400,300);
        setPaintOrder(Lives.class,Towers.class,Bullet.class,HealthBar.class,Mobs.class,Buttons.class,EndPoint.class,PathCell.class,BuildableCell.class,infoPanel.class);
        addObject(startWaveButton,700,520);

        prepare();
    }

    /**
     * the act method for the world
     */
    public void act()
    {
        //UNCOMMENT the following, and background music will be played.
        background.play();
        if(background.isPlaying()==false){
            background.play();
        }

        //creates mobs on the field
        createMobs();

        //checks if all the mobs in the wave has spawned then ends the wave
        if (mobsToSpawn==totalNumOfMobs)
        {
            finishedWave= true;
        }
        //checks if all the mobs on the field are gone, that the wave arraylist had at least one object, the waves has started and that the previous wave has finished
        if (getObjects(Mobs.class).isEmpty() && wave.size()>0 && start== true && finishedWave== true)
        {
            //changed the level and resets the the amount of mobs that needs to be spawned in the next level
            nextLevel();
            mobsToSpawn = 0;
        }

        //when the players lives reaches 0 then game over
        if (numLives <= 0)
        {
            gameOver();
        }

    }

    /**
     * Spawns mobs on the field. The first 4 waves are preset mobs to let the player have a taste of all the mob types in the game, then
     * the next waves are random amounts of each mob type. Every 10 levels a boss appears
     */
    private void spawn()
    {
        //the counter makes sure there is some space between each mob
        counter++;
        //for the first level a round of normal mobs spawn
        if (level == 1)
        {
            //the counter must be greater than 50 and the player must have pressed the start wave button 
            if (counter>=40 && mobsToSpawn <totalNumOfMobs && start == true)
            {
                //adds mobs to the field
                addObject(wave.get(mobsToSpawn),spawnX,spawnY);
                mobsToSpawn++;
                counter=0;
            }
        }
        else if (level==2)
        {
            //for the second level a round of fast mobs spawn
            //the counter must be greater than 50 and the player must have pressed the start wave button 
            if (counter>=30 && mobsToSpawn <totalNumOfMobs && start == true)
            {
                //adds mobs to the field
                addObject(wave.get(mobsToSpawn),spawnX,spawnY);
                mobsToSpawn++;
                counter=0;
            }
        }
        else if (level==3)
        {
            //for the third level a round of slow mobs spawn
            //the counter must be greater than 50 and the player must have pressed the start wave button 
            if (counter>=50 && mobsToSpawn <totalNumOfMobs && start == true)
            {
                //adds mobs to the field
                addObject(wave.get(mobsToSpawn),spawnX,spawnY);
                mobsToSpawn++;
                counter=0;
            }
        }
        else if (level==4)
        {
            //for the fourth level a round of flying mobs spawn
            //the counter must be greater than 50 and the player must have pressed the start wave button 
            if (counter>=40 && mobsToSpawn <totalNumOfMobs && start == true)
            {
                //adds mobs to the field
                addObject(wave.get(mobsToSpawn),spawnX,spawnY);
                mobsToSpawn++;
                counter=0;
            }
        }
        else if (level%10==0)
        {
            //every ten levels a boss spawns
            //the counter must be greater than 50 and the player must have pressed the start wave button 
            if (counter>=50 && mobsToSpawn <totalNumOfMobs&& start == true)
            {
                //adds the boss to the field
                addObject(wave.get(mobsToSpawn),spawnX,spawnY);
                mobsToSpawn++;
                counter=0;
            }
        }
        else 
        {
            //for the rest of the levels there is a random number of each mob
            //the counter must be greater than 50 and the player must have pressed the start wave button 
            if (counter>=40 && mobsToSpawn <  (totalNumOfMobs) && start == true)
            {
                //adds mobs to the field
                addObject(wave.get(mobsToSpawn),spawnX,spawnY);
                mobsToSpawn++;
                counter=0;
            }
        }
        //the wave has not finished yet
        finishedWave= false;
    }

    /**
     * creates each mob and adds them to the array list
     */
    private void createMobs()
    {

        //checks if the wave has finished otherwise it will go straight to adding a mob to the field
        if (finishedWave == true && levelUp == true)
        {
            //creates a random number of each mob to be placed on the field
            numOfFastMobs =Greenfoot.getRandomNumber(20) +5;
            numOfNormalMobs= Greenfoot.getRandomNumber(20) +5;
            numOfSlowMobs= Greenfoot.getRandomNumber(10) +5;
            numOfFlyingMobs= Greenfoot.getRandomNumber(15)+ 5;
            ranType = Greenfoot.getRandomNumber(6);
            if (ranType == 0)
            {
                mobType = "normal";
            }
            else if (ranType == 1)
            {
                mobType = "fire";
            }
            else if (ranType == 2)
            {
                mobType = "water";
            }
            else if (ranType == 3)
            {
                mobType = "earth";
            }
            else if (ranType ==4 )
            {
                mobType = "wood";
            }
            else if (ranType == 5)
            {
                mobType = "metal";
            }

            levelUp = false;
            if (level == 1)
            {
                //if it is the first level make 19 normal mobs
                for (int i = 0; i < 20;i++)
                {
                    wave.add(new NormalMob(2,(level*15),3,"normal"));

                }
                //the total number of mobs however is 20
                totalNumOfMobs = 20;
            }
            else if (level == 2)
            {
                //if it is the second level make 19 fast mobs
                for (int i = 0; i < 20;i++)
                {
                    wave.add(new FastMob(4,(level*10),1,"normal"));

                }
                //the total number of mobs however is 20
                totalNumOfMobs =20;
            }
            else if (level == 3)
            {
                //if it is the third level make 9 slow mobs
                for (int i = 0; i < 10;i++)
                {
                    wave.add(new SlowMob(1,(level*40),5,"normal"));

                }
                //the total number of mobs however is 10
                totalNumOfMobs =10;
            }
            else if (level == 4)
            {
                //if it is the fourth level make 19 flying mobs
                for (int i = 0; i < 20;i++)
                {
                    wave.add(new FlyingMob(2,(level*20),4,"normal"));

                }
                //the total number of mobs however is 20
                totalNumOfMobs = 20;
            }
            else if (level%10 == 0)
            {
                //every 10 levels make a boss
                wave.add(new Boss(1,(level*50),20,mobType));
                totalNumOfMobs = 1;
            }
            else
            {
                //after the first four levels add a random amount of mobs to the arraylist
                for (int i = 0; i < numOfFastMobs;i++)
                {

                    wave.add(new FastMob(4,(level*5),1,mobType));

                }
                for (int i = 0; i < numOfSlowMobs;i++)
                {

                    wave.add(new SlowMob(1,(level*40),5,mobType));

                }
                for (int i = 0; i < numOfNormalMobs;i++)
                {

                    wave.add(new NormalMob(2,(level*10),3,mobType));

                }
                for (int i = 0; i < numOfFlyingMobs;i++)
                {

                    wave.add(new FlyingMob(2,(level*10),4,mobType));

                }
                //the total amount of mobs is all the random numbers generated above added together
                totalNumOfMobs=numOfFastMobs+numOfNormalMobs+numOfSlowMobs+numOfFlyingMobs;
            }
        }
        //calls the spawn method
        spawn();
    }

    /**
     * advances to the next level
     */
    public void nextLevel()
    {
        //clears out the arraylist so the next set of mobs can be added to the list
        wave.clear();
        //the level goes up
        level++;
        //the info panel is updated with the new level
        info.updateValues(money,level,numLives,score, tempTower, tempInfo);
        levelUp = true;
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        Greenfoot.setWorld(new Title());
        buildMap();
        addHearts();
    }

    /**
     * Reads a map from the text file and builds the world. 
     */
    private void buildMap()
    {
        //Scans the file into the array
        try
        {
            scan = new Scanner (new File(fileName + ".txt"));
            while (scan.hasNext())
            {
                for (int i = 0; i < 20; i++)
                {
                    mapFile[i] = scan.nextLine();
                }
            }
        }
        //Catches exception if the map file is not found
        catch (FileNotFoundException e)
        {
            System.out.println("Map Not Found!");
        }
        //Closes the scanner if it is used.
        finally
        {
            if (scan!= null)
            {
                scan.close();
            }
        }

        //Sends the array list of the file into map[x][y], character by character
        //x is for the number of lines in the file
        for (int y = 0; y < 20; y++)
        {
            //y is for each thingy going across
            for (int x = 0; x < 20; x++)
            {
                map[x][y] = mapFile[y].charAt(x);
                //System.out.print(mapFile[y].charAt(x));
            }
        }

        //Adds a cell to each array
        for (int i = 0; i < buildable.length; i++)
        {
            buildable[i] = new BuildableCell();
        }
        for (int i = 0; i < path.length; i++)
        {
            path[i] = new PathCell();
        }
        for (int i = 0; i < turnpoint.length; i++)
        {
            turnpoint[i] = new turnPoint();
        }

        //Temporary integers to keep track of which array it is on
        int q = 0;
        int w = 0;
        int e = 0;
        //65 to 90 are the ASCII integers for char "A" to "Z". In the textfiles, the turn points are marked using letters 
        //so that they can be added in order.
        for (int i = 65; i < 90; i++){
            //checks through the map
            for (int a = 0; a < 20; a++)
            {
                for (int b = 0; b < 20; b++)
                {
                    char location = map[b][a];
                    if (location == (char)i){
                        if (e<turnpoint.length){
                            addObject(turnpoint[e], (b*30)+15,(a*30)+15);
                            //sets the "nextTurnPoint" for the previous turnPoint as this turnPoint
                            //the last one will be taken care later
                            if(e>=1){
                                turnpoint[e-1].setNextTurnPoint(turnpoint[e]);
                            }
                            e+=1;                            
                        }
                    }
                    if (location == (char)65){
                        spawnX = turnpoint[0].getX();
                        spawnY = turnpoint[0].getY();
                    }
                }
            }    
        } 

        for (int a = 0; a < 20; a++)
        {
            for (int b = 0; b < 20; b++)
            {
                char location = map[b][a];
                if (location=='0')
                {
                    if (q < 400)
                    {
                        //Adds in the buildable cell at the x location (b*30) to make up for the cell size, and +15 due to
                        //how the objects are added from the center of the location. The same for the y location (a*30)+15
                        addObject(buildable[q], (b*30)+15, (a*30) + 15);
                        q+=1;
                    }
                }
                //If the map reads a 1, it will make a path cell up to 100 cells.
                if (location == '1')
                {
                    if (w < 100)
                    {
                        //Adds in the path cell at the x location (b*30) to make up for the cell size, and +15 due to
                        //how the objects are added from the center of the location. The same for the y location (a*30)+15
                        addObject(path[w], (b*30)+15, (a*30) + 15);
                        w+=1;
                    }
                }
                if (location == '3')
                {
                    addObject(new turnPoint(), (b*30)+15, (a*30)+15);
                    addObject(endpoint, (b*30)+15, (a*30)+15); 
                    //the "nextTurnPoint" of the last turnPoint is set as the endPoint
                    turnpoint[e-1].setNextTurnPoint(endpoint);
                }
            }
        }   

    }

    /**
     * creates a tower based on which one you specify and adds the object to the screen. The amount of money is decreased and 
     * the values in the info panel are changed.
     * 
     * @param tower the tower that you want to build on the map
     */
    public void createTower(String tower)
    {
        //checks the tower the player wants to build using strings as well as if the player 
        //has enough money to build one
        if (tower.equals("arrow") && money >=20)
        {
            //builds an arrow tower
            //adds a new object into the arraylist which gets added to the world
            arrowTowers.add(new ArrowTower(numOfArrowTowers));
            addObject(arrowTowers.get(numOfArrowTowers),buildX,buildY);
            //increases the total number of arrow towers there are
            numOfArrowTowers++;
            //money decreases
            money = money-20;
            //values are updated
            info.updateValues(money,level,numLives,score, tempTower, tempInfo);

        }
        else if (tower.equals("rocket")&& money >=30)
        {
            //builds a rocket tower
            //adds a new object into the arraylist which gets added to the world
            rocketTowers.add(new RocketTower(numOfRocketTowers));
            addObject(rocketTowers.get(numOfRocketTowers),buildX,buildY);
            //increases the total number of rocket towers
            numOfRocketTowers++;
            //money decreases
            money = money-30;
            //values are updated
            info.updateValues(money,level,numLives,score, tempTower, tempInfo);
        }
        else if (tower.equals("laser")&& money >=20)
        {
            //builds a laser tower
            //adds a new object into the arraylist which gets added to the world
            laserTowers.add(new LaserTower(numOfLaserTowers));
            addObject(laserTowers.get(numOfLaserTowers),buildX,buildY);
            //increases the total number of laser towers
            numOfLaserTowers++;
            //money decreases
            money = money-20;
            //values are updated
            info.updateValues(money,level,numLives,score, tempTower, tempInfo);
        }
        else if (tower.equals("fire")&& money >=200)
        {
            //builds a f tower
            //adds a new object into the arraylist which gets added to the world
            fireTowers.add(new FireTower(numOfFireTowers));
            addObject(fireTowers.get(numOfFireTowers),buildX,buildY);
            //increases the total number of laser towers
            numOfFireTowers++;
            //money decreases
            money = money-200;
            clearTemp();
            //values are updated

            info.updateValues(money,level,numLives,score, tempTower, tempInfo);
        }
        else if (tower.equals("water")&& money >=170)
        {
            //builds a water tower
            //adds a new object into the arraylist which gets added to the world
            waterTowers.add(new WaterTower(numOfWaterTowers));
            addObject(waterTowers.get(numOfWaterTowers),buildX,buildY);
            //increases the total number of water towers
            numOfWaterTowers++;
            //money decreases
            money = money-170;
            clearTemp();
            //values are updated
            info.updateValues(money,level,numLives,score, tempTower, tempInfo);
        }
        else if (tower.equals("wood")&& money >=170)
        {
            //builds a wood tower
            //adds a new object into the arraylist which gets added to the world
            woodTowers.add(new WoodTower(numOfWoodTowers));
            addObject(woodTowers.get(numOfWoodTowers),buildX,buildY);
            //increases the total number of wood towers
            numOfWoodTowers++;
            //money decreases
            money = money-170;
            clearTemp();
            //values are updated
            info.updateValues(money,level,numLives,score, tempTower, tempInfo);
        }
        else if (tower.equals("metal")&& money >=150)
        {
            //builds a metal tower
            //adds a new object into the arraylist which gets added to the world
            metalTowers.add(new MetalTower(numOfMetalTowers));
            addObject(metalTowers.get(numOfMetalTowers),buildX,buildY);
            //increases the total number of metal towers
            numOfMetalTowers++;
            //money decreases
            money = money-150;
            clearTemp();
            //values are updated
            info.updateValues(money,level,numLives,score, tempTower, tempInfo);
        }
        else if (tower.equals("earth")&& money >=230)
        {
            //builds a earth tower
            //adds a new object into the arraylist which gets added to the world
            earthTowers.add(new EarthTower(numOfEarthTowers));
            addObject(earthTowers.get(numOfEarthTowers),buildX,buildY);
            //increases the total number of earth towers
            numOfEarthTowers++;
            //money decreases
            money = money-230;
            clearTemp();
            //values are updated
            info.updateValues(money,level,numLives,score, tempTower, tempInfo);
        }

        else
        {
            //the only reason this would be called is if the player does not have enough money
            info.update("not enough money");
        }
        //resets the values that were temporarily held
        tempTower = "";
        tempID = -1;
        tempInfo = "";

        //deletes the option to build towers
        deleteTowerOptionButton("build");
    }  

    /**
     * gets the total amount of money the player has
     * 
     * @return int the money the player has
     */
    public int getMoney()
    {
        return money;
    }

    /**
     * removes a tower but the player does not get money back
     */
    public void removeTower()
    {
        //checks the what the last tower the player had clicked on and deletes it
        if (tempTower.equals("arrow"))
        {
            //the player wants to delete an arrow tower
            //looks through the arraylist of arrow towers
            for (ArrowTower a: arrowTowers)
            {
                //checks every arrow tower to match the ID of the tower
                if (a.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(a);
                }
            }
        }
        else if (tempTower.equals("rocket"))
        {
            //the player wants to delete a rocket tower
            //looks through the arraylist of rocket towers
            for (RocketTower r: rocketTowers)
            {
                //checks every rocket tower to match the ID of the tower
                if (r.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(r);
                }
            }
        }
        else if (tempTower.equals("laser"))
        {
            //the player wants to delete an laser tower
            //looks through the arraylist of laser towers
            for (LaserTower l: laserTowers)
            {
                //checks every laser tower to match the ID of the tower
                if (l.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(l);
                }
            }
        }
    }

    /**
     * deletes a tower and the player gains some money back
     */
    public void deleteTower()
    {
        //checks the what the last tower the player had clicked on and deletes it
        if (tempTower.equals("arrow"))
        {
            //the player wants to delete an arrow tower
            //looks through the arraylist of arrow towers
            for (ArrowTower a: arrowTowers)
            {
                //checks every arrow tower to match the ID of the tower
                if (a.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(a);
                    //money is gained
                    money = money +(int)(a.getCost()*0.9);
                    //values are updated
                    info.updateValues(money,level,numLives,score, tempTower,tempInfo);
                }
            }
        }
        else if (tempTower.equals("rocket"))
        {
            //the player wants to delete a rocket tower
            //looks through the arraylist of rocket towers
            for (RocketTower r: rocketTowers)
            {
                //checks every rocket tower to match the ID of the tower
                if (r.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(r);
                    //money is gained
                    money = money +(int)(r.getCost()*0.9);
                    //values are updated
                    info.updateValues(money,level,numLives,score,tempTower,tempInfo);
                }
            }
        }
        else if (tempTower.equals("laser"))
        {
            //the player wants to delete an laser tower
            //looks through the arraylist of laser towers
            for (LaserTower l: laserTowers)
            {
                //checks every laser tower to match the ID of the tower
                if (l.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(l);
                    //money is gained
                    money = money +(int)(l.getCost()*0.9);
                    //values are updated
                    info.updateValues(money,level,numLives,score,tempTower,tempInfo);
                }
            }
        }
        else if (tempTower.equals("fire"))
        {
            //the player wants to delete a fire tower
            //looks through the arraylist of fire towers
            for (FireTower f: fireTowers)
            {
                //checks every fire tower to match the ID of the tower
                if (f.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(f);
                    //money is gained
                    money = money +(int)(f.getCost()*0.9);
                    //values are updated
                    info.updateValues(money,level,numLives,score,tempTower,tempInfo);
                }
            }
        }
        else if (tempTower.equals("water"))
        {
            //the player wants to delete a water tower
            //looks through the arraylist of water towers
            for (WaterTower wa: waterTowers)
            {
                //checks every water tower to match the ID of the tower
                if (wa.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(wa);
                    //money is gained
                    money = money +(int)(wa.getCost()*0.9);
                    //values are updated
                    info.updateValues(money,level,numLives,score,tempTower,tempInfo);
                }
            }
        }
        else if (tempTower.equals("metal"))
        {
            //the player wants to delete a metal tower
            //looks through the arraylist of metal towers
            for (MetalTower m: metalTowers)
            {
                //checks every metal tower to match the ID of the tower
                if (m.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(m);
                    //money is gained
                    money = money +(int)(m.getCost()*0.9);
                    //values are updated
                    info.updateValues(money,level,numLives,score,tempTower,tempInfo);
                }
            }
        }
        else if (tempTower.equals("wood"))
        {
            //the player wants to delete a wood tower
            //looks through the arraylist of wood towers
            for (WoodTower wo: woodTowers)
            {
                //checks every wood tower to match the ID of the tower
                if (wo.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(wo);
                    //money is gained
                    money = money +(int)(wo.getCost()*0.9);
                    //values are updated
                    info.updateValues(money,level,numLives,score,tempTower,tempInfo);
                }
            }
        }
        else if (tempTower.equals("earth"))
        {
            //the player wants to delete an earth tower
            //looks through the arraylist of earth towers
            for (EarthTower e: earthTowers)
            {
                //checks every earth tower to match the ID of the tower
                if (e.getID()==tempID)
                {
                    //once the ID is found the tower is deleted 
                    removeObject(e);
                    //money is gained
                    money = money +(int)(e.getCost()*0.9);
                    //values are updated
                    info.updateValues(money,level,numLives,score,tempTower,tempInfo);
                }
            }
        }
        //resets the values that were temporarily held
        tempTower = "";
        tempID = -1;
        tempInfo = "";
        tempLevel = -1;
        tempName = "";
        //updates the panel
        info.update();
        //the option to delete towers is removed
        deleteTowerOptionButton("upgrade");
    }

    /**
     * creates buttons in the info panel for the user to click on
     * 
     * @param create   the used to specify which types of buttons to create 
     * @param x        only used if the user wants to build a tower and is the x coordinates of where to build one
     * @param y        only used if the user wants to build a tower and is the y coordinates of where to build one
     * @param tower    only used if the user wants to build a tower and is the type of tower to build
     */
    public void createTowerOptionButton(String create, int x, int y, String tower)
    {
        //checks whether the user wants to build a tower or modify a tower
        if (create.equals("build"))
        {
            //the user wants to build a tower
            //the x and y coordinates are used in the create tower method as the coordinates of the new tower
            buildX=x;
            buildY=y;
            //adds three buttons for the user to click on and build a tower
            addObject(arrowTowerButton,640,220);
            addObject(rocketTowerButton,690,220);
            addObject(laserTowerButton,740,220);

            //deletes extra buttons
            deleteTowerOptionButton("upgrades");

        }
        else if (create.equals("upgrade") && tempLevel < 5)
        {
            //the user wants to modify a tower
            //adds two buttons at the bottom of the info panel for the user to click on
            addObject(sellButton,650,580);
            addObject(upgradeButton,750,580);
            deleteTowerOptionButton("build");
        }
        else if (create.equals("upgrade") && tempLevel == 5)
        {
            //deletes exra buttons
            deleteTowerOptionButton("build");
            deleteTowerOptionButton("upgrade");
            info.update();
            //holds temporary information
            buildX = x;
            buildY = y;
            //adds buttons based on which tower was selectd
            if (tower.equals("laser"))
            {
                addObject(metalTowerButton,640,220);
            }
            else if (tower.equals("arrow"))
            {
                addObject(waterTowerButton,640,220);
                addObject(woodTowerButton,690,220);

            }
            else if (tower.equals("rocket"))
            {
                addObject(earthTowerButton,640,220);
                addObject(fireTowerButton,690,220);

            }

        }
        else if (create.equals("sell"))
        {
            //adds only the sell button
            addObject(sellButton,650,580);
        }
    }

    /**
     * deletes buttons to make sure the info panel is clear of extra buttons
     * 
     * @param delete specify what to delete in the panel
     */
    public void deleteTowerOptionButton(String delete)
    {
        //deletes buttons that build towers
        if (delete.equals("build"))
        {
            removeObject(arrowTowerButton);
            removeObject(rocketTowerButton);
            removeObject(laserTowerButton);
            //checks for extra buttons and deletes them
            if (getObjects(MetalTowerButton.class)!=null)
            {
                removeObject(metalTowerButton);

            }
            if (getObjects(FireTowerButton.class)!=null)
            {
                removeObject(fireTowerButton);
            }
            if (getObjects(WaterTowerButton.class)!=null)
            {
                removeObject(waterTowerButton);
            }
            if (getObjects(WoodTowerButton.class)!=null)
            {
                removeObject(woodTowerButton);
            }
            if (getObjects(EarthTowerButton.class)!=null)
            {
                removeObject(earthTowerButton);
            }
        }
        else if (delete.equals("upgrade"))
        {
            //deletes buttons that upgrades towers
            if (getObjects(SellButton.class)!=null)
            {
                removeObject(sellButton);
            }
            if (getObjects(UpgradeButton.class)!=null)
            {
                removeObject(upgradeButton);
            }
        }
    }

    /**
     * checks for the specific tower and upgrades the tower by changing stats and the image
     */
    public void upgradeTower()
    {
        //checks the tower that was clicked on
        if (tempTower.equals("arrow"))
        {
            //checks for each arrow tower
            for (ArrowTower a: arrowTowers)
            {
                if (a.getID()==tempID && tempLevel < 5 )
                {
                    if (money >=a.getCost())
                    {
                        //increase damage
                        a.setDamage(a.getDamage() + 10);
                        //increase level
                        a.setLevel(tempLevel + 1);
                        //change the range
                        a.setRange(a.getRange() + 30);
                        //change image to show upgrade
                        a.setImage("arrowtower"+(tempLevel+1)+".png");
                        //decrease money
                        money = money - a.getCost();
                        //change cost
                        a.setCost(a.getCost()+20);
                        //change name
                        a.setName(tempTower+"lv"+(tempLevel+1));
                        //change info
                        a.setInfo("Damage:"+(a.getDamage()+10)+"\nRange:"+(a.getRange()+30)+"\nCost: $" +(a.getCost()) + "\nSpeed: Normal" );
                        //clears values
                        clearTemp();
                        //updates the panel
                        info.updateValues(money,level,numLives,score,tempTower, tempInfo);
                        deleteTowerOptionButton("upgrade");

                    }
                    else 
                    {
                        //the only reason this would be called is if the player does not have enough money

                        info.update("not enough money");
                    }
                }

            }
        }
        else if (tempTower.equals("rocket"))
        {
            //checks for each rocket tower
            for (RocketTower r: rocketTowers)
            {
                if (r.getID()==tempID && tempLevel < 5 )
                {
                    if ( money >= r.getCost())
                    {
                        //increase damage
                        r.setDamage(r.getDamage() + 15);
                        //increase level
                        r.setLevel(tempLevel+ 1);
                        //change the range
                        r.setRange(r.getRange() + 10);
                        //change image to show upgrade
                        r.setImage("rockettower"+(tempLevel+1)+".png");
                        //decrease money
                        money = money - r.getCost();
                        //change cost
                        r.setCost(r.getCost()+20);
                        //change name
                        r.setName(tempTower+"lv"+(tempLevel+1));
                        //change info
                        r.setInfo("Damage:"+(r.getDamage()+15)+"\nRange:"+(r.getRange()+10)+"\nCost: $" +(r.getCost()) + "\nSpeed: Slow" );

                        //clears values
                        clearTemp();
                        //updates the panel
                        info.updateValues(money,level,numLives,score,tempTower, tempInfo);
                        deleteTowerOptionButton("upgrade");
                    }
                    else 
                    {
                        //the only reason this would be called is if the player does not have enough money
                        info.update("not enough money");
                    }
                }
            }
        }
        else if (tempTower.equals("laser"))
        {
            //checks for each laser tower
            for (LaserTower l: laserTowers)
            {
                if (l.getID()==tempID && tempLevel < 5 )
                {
                    if (money >=l.getCost())
                    {
                        //increase damage
                        l.setDamage(l.getDamage() + 2);
                        //increase level
                        l.setLevel(tempLevel + 1);
                        //change the range
                        l.setRange(l.getRange() + 20);
                        //change image to show upgrade
                        l.setImage("lasertower"+(tempLevel+1)+".png");
                        //decrease money
                        money = money - l.getCost();
                        //change cost
                        l.setCost(l.getCost()+20);
                        //change name
                        l.setName(tempTower+"lv"+(tempLevel+1));
                        //change info
                        l.setInfo("Damage:"+(l.getDamage()+3)+"\nRange:"+(l.getRange()+20)+"\nCost: $" +(l.getCost()) + "\nSpeed: fast" );
                        //clears values
                        clearTemp();
                        //updates the panel
                        info.updateValues(money,level,numLives,score,tempTower, tempInfo);
                        deleteTowerOptionButton("upgrade");
                    }
                    else 
                    {
                        //the only reason this would be called is if the player does not have enough money
                        info.update("not enough money");
                    }
                }

            }
        }

    }

    /**
     *  holds information about the most recent tower that was clicked on
     *  
     *  @param tower the type of tower
     *  @param ID    the ID of the tower
     *  @param info  the description of the tower
     *  @param name  the name of the tower
     */
    public void infoHold(String tower, int ID, String info, int level, String name)
    {
        tempID = ID;
        tempTower = tower;
        tempInfo = info;
        tempLevel = level;
        tempName = name;
    }

    /**
     * creates a bullet to shoot at the enemy
     * 
     * @param x      the x coordinates of where to place the bullet
     * @param y      the y coordinates of where to place the bullet
     * @param tower  the type of tower shooting the bullet 
     * @param actor  the target to shoot at
     * @param dmg    the damage the tower does
     */
    public void shoot(int x, int y , String tower, Actor target, int dmg)
    {
        //checks which tower is shooting and creates the appropriate bullet
        if (tower.equals("laser"))
        {
            addObject(new Laser(target, dmg),x,y);
        }
        else if (tower.equals("arrow"))
        {
            addObject(new Arrow(target,dmg),x,y);
        }
        else if (tower.equals("rocket"))
        {
            addObject(new Rocket(target,dmg),x,y);
        }
        else if (tower.equals("fire"))
        {
            addObject(new Fire(target,dmg),x,y);
        }
        else if (tower.equals("water"))
        {
            addObject(new Water(target,dmg),x,y);
        }
        else if (tower.equals("wood"))
        {
            addObject(new Wood(target,dmg),x,y);
        }
        else if (tower.equals("metal"))
        {
            addObject(new Metal(target,dmg),x,y);
        }
        else if (tower.equals("earth"))
        {
            addObject(new Earth(target,dmg),x,y);
        }

    }

    /**
     * Static method that gets the distance between the x,y coordinates of two Actors
     * using Pythagorean Theorum.
     * Credits to Mr. Cohen
     * 
     * @param a     First Actor
     * @param b     Second Actor
     */
    public double getDistance (Actor b, Towers a)
    {

        double distance;

        double xLength = b.getX() - a.getX();
        double yLength = b.getY() - a.getY();
        distance = Math.sqrt(Math.pow(xLength, 2) + Math.pow(yLength, 2));

        return distance;

    }

    /**
     * starts the wave of monsters
     */
    public void startWaves()
    {
        start = true;
    }

    /**
     * deletes the start wave button
     */
    public void deleteStartButton()
    {
        removeObject(startWaveButton);
    }

    /**
     * Adds in the hearts that are shown in the top left corner during game play.
     */
    private void addHearts()
    {
        //t is a temporary integer to keep track of which life is being added
        //y is the y-location the hearts are being added to.
        int t = 0;
        int y;
        for (int i = 0; i < 20; i++)
        {
            lives[i] = new Lives();
        }
        /**Adds the hearts to it's location. 2 rows of 10
         * x starts at 0 and adds up, it is then multiplied by 15 to work out the spacing inbetween the cells and 630
         *is the x-location
         */
        for (int x = 0; x<10 ; x++)
        {
            if (t < 10)
            {
                y = 120;
                addObject(lives[t], (x*15)+630, y);
                t+=1;
            }
        }
        for (int x = 0; x<10 ; x++)
        {
            if (t>=10)
            {
                y = 135;
                addObject(lives[t], (x*15)+630, y);
                t+=1;
            }
        }
    }

    /**
     * Removes  hearts; method gets called from the Mobs class.
     * 
     * @param type the the name of the mob
     */
    public void removeLife(String type)
    {
        if (numLives > 0)
        {
            //if a boss reaches the castle then the player loses 5 lives
            if (type.equals("boss"))
            {
                for (int i = 0;i<5;i++)
                {
                    numLives -=1;
                    lives[numLives].setImage(emptyHeart);
                }
            }
            else
            {
                numLives-=1;
                lives[numLives].setImage(emptyHeart);
            }

            death.play();
            info.updateValues(money,level,numLives,score,tempTower,tempInfo );

        }
    }

    /**
     * changes the world to highscorespage when the player loses
     */
    private void gameOver()
    {
        pName = JOptionPane.showInputDialog("Game Over! Enter your name to submit your score");
        if (pName == null)
        {
            pName = "Player";
        }
        addToFile();
        Greenfoot.setWorld(new HighScoresPage());
    }

    /**
     * adds an explosion in the world
     * 
     * @param x   The x coordinate of where to place the explosion
     * @param y   The y coordinate of where to place the explosion
     * @param dmg The damage of the tower
     */
    public void addExplosion(int x, int y, int dmg)
    {
        addObject(new Explosion(dmg),x,y);
    }

    /**
     * gives the player money after they successfully defeated a mob and updates the score
     * 
     * @param name  the name/type of the mob
     */
    public void getMoney(String name)
    {
        //checks the name/type of the mob and gives the appropriate amount of money
        //also adds points to the score
        if (name.equals("normal"))
        {
            //when a normal mob is killed
            money= (int)(money+ (level/15)+1);
            score = score + 5;
        }
        else if (name.equals("fast"))
        {
            //when a fast mob is killed
            money= (int)(money+ (level/20)+1);
            score = score + 2;
        }
        else if (name.equals("slow"))
        {
            //when a slow mob is killed
            money= (int)(money+ (level/5)+1);
            score = score + 10;
        } 
        else if (name.equals("flying"))
        {
            //when a flying mob is killed
            money= (int)(money+ (level/10)+2);
            score = score + 7;
        } 
        else if (name.equals("boss"))
        {
            //when a boss is killed
            money= (int)(money+ (level*10));
            score = score + 20;
        }
        //updates the money and the score
        info.updateValues(money,level,numLives,score,tempName, tempInfo);
    }

    /**
     * clears the temporarily stored information on the towers
     */
    public void clearTemp()
    {
        tempTower ="";
        tempInfo = "";
        tempID = -1;
        tempLevel=-1;
        tempName = "";
    }

    /**
     * Saves the score on top of an existing file
     */
    private void addToFile()
    {
        s = Integer.toString(score);
        WriteFile data = new WriteFile("High_Scores.txt", true);
        try
        {
            data.writeToFile(pName + " " + s);
        }
        catch (java.io.IOException e)
        {
            System.out.println( "Text File Written To" );
        }
    }
}