import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

import javax.swing.JOptionPane;

/**
 * High Scores paage that displays the 5 most recent scores
 * 
 * @author Amanda Mak
 * @version Jan 2014
 */
public class HighScoresPage extends World
{
    private BackButton Back = new BackButton();
    private showScore showscore = new showScore();
    //thing: whether or not the gamer has a score

    /**
     * Constructor for objects of class HighScoresPage.
     */
    public HighScoresPage()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
    }
    /**
     * Adds in the objects that show up in the world
     */
    private void prepare()
    {
        addObject(Back, 400, 425);
        addObject(showscore,400,200);
    }
    /**
     * Act - Do whatever the showScore wants to do. THis method is called whenever
     * the 'act' or 'run' button gets pressed in the environment
     */
    public void act()
    {
        goBack();
    }
    /**
     * If the user presses the 'back' button, they are returned to the title page
     */
    private void goBack()
    {
        if (Greenfoot.mouseClicked(Back))
        {
            Greenfoot.setWorld(new Title());
        }
    }
}
