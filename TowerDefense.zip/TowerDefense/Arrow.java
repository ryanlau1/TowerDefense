import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The arrow class is a subclass of the bullet class. It has normal speed and is only
 * used by the arrow towers and its upgrades.
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class Arrow extends Bullet
{

    public Arrow(Actor t, int dmg)
    {
        damage = dmg;
        target = t;
        this.speed = 20;
        this.type = "arrow";
        s = new GreenfootSound ("arrow.wav");
    }

    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //plays the sound effect
        s.play();
        //moves the bullet
        move(speed);
        //checks if the bullet is at the worlds edge
        atWorldEdge();

    }

    /**
     * overrides the addedToWorld method in the actor super class and makes sure that as the bullet spawns it
     * turns towards the target
     * 
     * @param w gets the world
     */
    public void addedToWorld (World w)
    {
        turnTowards(target.getX(),target.getY());
    }

}