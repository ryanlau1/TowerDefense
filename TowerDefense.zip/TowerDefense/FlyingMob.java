import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * FlyingMob is a subclass of the Mob parent class. 
 * It has relatively low health but moves really fast.
 * 
 * @Yao Lu, Natalie Lee, Ryan Lau
 * @version 1
 */
public class FlyingMob extends Mobs
{
    /**
     * Construction defines detailed basic info of the mob
     * 
     * @param speed The speed of the mob
     * @param health Health Point of the mob
     * @param Defense Defense of the mob
     * @param Type of the mob
     */ 
    public FlyingMob(int speed, int health, int defense, String type)
    {
        this.speed=speed;
        this.health = health;
        this.defense = defense;
        this.type = type;
        this.name = "flying";
                //the type of the mob decides which image to use
        if (type == "normal")
        {
            setImage("Caterpie.png");   
        }
        else if (type == "fire")
        {
            setImage("Charizard.png");
        }
        else if (type == "water")
        {
            setImage("Gyarados.png");
        }
        else if (type == "earth")
        {
            setImage("Gliscor.png");
        }
        else if (type == "wood")
        {
            setImage("Jumpluff.png");
        }
        else if (type == "metal")
        {
            setImage("Skarmory.png");
        }
    } 

    public void act() 
    {
        //adds a health bar for the mob
        if (healthBar == null){
            healthBar = new HealthBar(45,8,6,health,health);
            getWorld().addObject(healthBar, getX(), getY()-20);
        }else{
            //once added, the health bar is updated throughout the game 
            //so that it follows the mob
            healthBar.setLocation(this.getX(),this.getY()-20);  
        }
                ifClicked();
        checkBullet();
        moveAlongPath(speed);
    } 
}
