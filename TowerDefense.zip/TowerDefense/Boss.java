import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The boss of the game, while there are multiple bosses, each one has their own strength and weaknesses
 * 
 * @author Yao Lu, Ryan Lau, Natalie Lee
 * @version 1
 */
public class Boss extends Mobs
{
    /**
     * Construction defines detailed basic info of the mob
     * 
     * @param speed The speed of the mob
     * @param health Health Point of the mob
     * @param Defense Defense of the mob
     * @param Type of the mob
     */ 
    public Boss(int speed, int health, int defense, String type)
    {
        this.speed=speed;
        this.health = health;
        this.defense = defense;
        this.type = type;
        this.name = "boss";
                //the type of the mob decides which image to use
        if (type == "normal")
        {
            setImage("Arceus.png");   
        }
                else if (type == "fire")
        {
            setImage("Moltres.png");
        }
         else if (type == "water")
        {
            setImage("Latios.png");
        }
         else if (type == "earth")
        {
            setImage("Groudon.png");
        }
         else if (type == "wood")
        {
            setImage("Shaymin.png");
        }
         else if (type == "metal")
        {
            setImage("Regigigas.png");
        }
    } 

    public void act() 
    {
        //adds a health bar for the mob
        if (healthBar == null){
            healthBar = new HealthBar(45,8,6,health,health);
            getWorld().addObject(healthBar, getX(), getY()-20);
        }else{
            //once added, the health bar is updated throughout the game 
            //so that it follows the mob
            healthBar.setLocation(this.getX(),this.getY()-20);  
        }
        ifClicked();
        checkBullet();
        moveAlongPath(speed);
    }
}
