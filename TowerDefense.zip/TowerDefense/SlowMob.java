import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * SlowMob is a subclass of the Mob parent class. 
 * It has reallt high health point but moves very slowly.
 * 
 * @Yao Lu, Ryan Lau, Natalie Lee
 * @version 1
 */
public class SlowMob extends Mobs
{
    /**
     * Construction defines detailed basic info of the mob
     * 
     * @param speed The speed of the mob
     * @param health Health Point of the mob
     * @param Defense Defense of the mob
     * @param Type of the mob
     */ 
    public SlowMob(int speed, int health, int defense,  String type)
    {
        this.speed=speed;
        this.health = health;
        this.defense = defense;
        this.type = type;
        this.name = "slow";
        //the type of the mob decides which image to use
        if (type == "normal")
        {
            setImage("Snorlax.png");   
        }
        else if (type == "fire")
        {
            setImage("Camerupt.png");
        }
        else if (type == "water")
        {
            setImage("Blastoise.png");
        }
        else if (type == "earth")
        {
            setImage("Nidoking.png");
        }
        else if (type == "wood")
        {
            setImage("Venusaur.png");
        }
        else if (type == "metal")
        {
            setImage("Aggron.png");
        }
    } 

    public void act() 
    {
        //adds a health bar for the mob
        if (healthBar == null){
            healthBar = new HealthBar(45,8,6,health,health);
            getWorld().addObject(healthBar, getX(), getY()-20);
        }else{
            //once added, the health bar is updated throughout the game 
            //so that it follows the mob
            healthBar.setLocation(this.getX(),this.getY()-20);  
        }
        ifClicked();
        checkBullet();
        moveAlongPath(speed);
    }      
}
