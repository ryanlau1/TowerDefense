import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The fire tower button lets the user build a fire tower
 * 
 * @author Natalie Lee, Ahsen Husain
 * @version Jan 2014
 */
public class FireTowerButton extends Buttons
{
    /**
     * constructor for the fire tower button
     */
    public FireTowerButton()
    {
        image = new GreenfootImage("firetowerbutton.png");
        setImage(image);
    }

    /**
     * Act - do whatever the FireTowerButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        myWorld m = (myWorld)getWorld();
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        //checks for the mouse
        if (Greenfoot.mouseMoved(this))
        {
            //updates information
            updateImage("firetowerbutton");
            i.update("Damage:150 \nRange:200 \nCost: $200 \nSpeed: Slow");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("firetowerbutton");
        }
        else if (Greenfoot.mouseClicked(this))
        {
            //removes the previous tower if the player can build this tower
                       if (m.getMoney() >=200)
            {
                m.removeTower();
            }
            m.createTower("fire");
        }
    }    
}
