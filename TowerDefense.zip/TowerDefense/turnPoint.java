import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * TurnPoint is a class that represents the corners in the path.
 * They are added in the order in which the mobs will pass through.
 * Each turn point has a variable that is the next target, 
 * so that the mobs can use it as a reference to move along the path.
 * 
 * @Yao Lu
 * @version 1
 */
public class turnPoint extends Actor
{
    //the next turn point, which is defined in the world.
    private turnPoint next;
    /**
     * Act - do whatever the turnPoint wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       //use the current turn point as a placeholder for the next
        if (next == null){
            next = this;
        }
        myWorld m = (myWorld)getWorld();
        // Add your action code here.
        if (Greenfoot.mouseClicked(this))
        {
            m.clearTemp();
        }
    }    

    /**
     * Returns the next turnPoint
     * 
     * @return the next turnPoint
     */
    public turnPoint getNextTurnPoint()
    {
        return next;
    }

    /**
     * Sets the next turnPoint
     * 
     * @param t The next turnPoint
     */
    public void setNextTurnPoint(turnPoint t){
        next = t;
    }
}
