import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The title page for RAAYN's (Ryan, Ahsen, Amanda, Yao and Natalie) Tower Defense
 * 
 * @author Amanda Mak
 * @version Jan 2014
 */
public class Title extends World
{

    /**
     * Constructor for objects of class Title.
     */
    public Title()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
    }
    /**
     * Adds objects into the world
     */
    private void prepare()
    {
        StartButton start = new StartButton();
        InstructionsButton instructions = new InstructionsButton();
        HighScoresButton highscores = new HighScoresButton();
        
        addObject(start, 400, 425);
        addObject(instructions, 400, 485);
        addObject(highscores, 400, 545);
    }
}
