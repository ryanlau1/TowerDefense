import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;  
/**
 * The info panel is a class that displays infomation and managed user interactions with the game. The panel displays 
 * the users current status such as the number of lives they have left, the current amount of money they have etc. it also allows
 * buttons to be pressed on the screen so the player can add, sell, upgrade towers. It uses method overloading to update 
 * different parts of the infopanel.
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class infoPanel extends Actor
{
    private GreenfootImage panel;
    private GreenfootImage bg = new GreenfootImage("panel.png");
    private int money;
    private int level;
    private int lives;
    private int score;

    /**
     * the constructor for the info panel
     *
     * @param money the startng amount of money
     * @param level the starting level
     * @param lives the starting amount of lives
     * @param score the starting score
     */
    public infoPanel(int money, int level, int lives, int score)
    {
        panel = new GreenfootImage(800,600);
        this.money = money;
        this.level = level;
        this.lives =lives;
        this.score = score;
        update("");
    }

    /**
     * Act - do whatever the infoPanel wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        myWorld m = (myWorld)getWorld();
        // Add your action code here.
        //if the user randomly clicks on the panel the temporary infomation held by the world will be erased
        if (Greenfoot.mouseClicked(this))
        {
            m.clearTemp();
        }
    } 

    /**
     * updates the values that are displayed on the info panel
     * 
     * @param money the current of money the player has
     * @param level the current level the player is on
     * @param lives the current amount of lives the player has
     * @param score the total score the player has
     * @param tower the tower that the player had previously clicked on
     * @param info  the description for the tower the player had previously clicked on
     */
    public void updateValues(int money, int level, int lives, int score, String tower, String info)
    {
        this.money = money;
        this.level = level;
        this.lives =lives;
        this.score = score;
        //updates the panel
        update(tower,info);
    }

    /**
     * updates only values in the info panel and erases unneccesary words.
     * Used when the player has click on random objects that do not react to clicking to clear info
     */
    public void update()
    {
        panel.clear();
        //the values on the info panel
        GreenfootImage towerLabel = new GreenfootImage(("Towers"),25,Color.WHITE,null);
        GreenfootImage infoMoney = new GreenfootImage(("Money: $"+Integer.toString(money)),25,Color.WHITE,null);
        GreenfootImage infoLives = new GreenfootImage(("Lives: "+Integer.toString(lives)),25,Color.WHITE,null);
        GreenfootImage infoLevel = new GreenfootImage(("Level: "+Integer.toString(level)),25,Color.WHITE,null);
        GreenfootImage infoScore = new GreenfootImage(("Score: "+Integer.toString(score)),25,Color.WHITE,null);
        //draws each image
        panel.drawImage(bg,600,0);
        panel.drawImage(towerLabel,620,170);
        panel.drawImage(infoLevel,620,30);
        panel.drawImage(infoMoney,620,50);
        panel.drawImage(infoScore,620,10);
        panel.drawImage(infoLives,620,70);
        //updates the panel
        setImage(panel);
    }

    /**
     * updates values and the description of the towers
     * used when the player has clicked/hovered over a button to look at the towers description
     * 
     * @param description  the information about the tower the player is looking at
     */
    public void update(String description)
    {
        panel.clear();
        //the values on the info panel
        GreenfootImage towerLabel = new GreenfootImage(("Towers"),25,Color.WHITE,null);
        GreenfootImage infoMoney = new GreenfootImage(("Money: $"+Integer.toString(money)),25,Color.WHITE,null);
        GreenfootImage infoLives = new GreenfootImage(("Lives: "+Integer.toString(lives)),25,Color.WHITE,null);
        GreenfootImage infoLevel = new GreenfootImage(("Level: "+Integer.toString(level)),25,Color.WHITE,null);
        GreenfootImage infoScore = new GreenfootImage(("Score: "+Integer.toString(score)),25,Color.WHITE,null);
        GreenfootImage information = new GreenfootImage(description,20,Color.WHITE,null);
        //draws each image
        panel.drawImage(bg,600,0);
        panel.drawImage(towerLabel,620,170);
        panel.drawImage(infoLevel,620,30);
        panel.drawImage(infoMoney,620,50);
        panel.drawImage(infoScore,620,10);
        panel.drawImage(infoLives,620,70);
        panel.drawImage(information,620,400);
        //updates the panel
        setImage(panel);
    }

    /**
     * updates the values and description as well as provides information about the next tower upgrades
     * 
     * @param type        the type of tower that the player currently has as is clicking on
     * @param description the description of the next tower upgrade
     */
    public void update(String type, String description)
    {
        panel.clear();
        //the values on the info panel
        GreenfootImage towerLabel = new GreenfootImage(("Towers"),25,Color.WHITE,null);
        GreenfootImage infoMoney = new GreenfootImage(("Money: $"+Integer.toString(money)),25,Color.WHITE,null);
        GreenfootImage infoLives = new GreenfootImage(("Lives: "+Integer.toString(lives)),25,Color.WHITE,null);
        GreenfootImage infoLevel = new GreenfootImage(("Level: "+Integer.toString(level)),25,Color.WHITE,null);
        GreenfootImage infoScore = new GreenfootImage(("Score: "+Integer.toString(score)),25,Color.WHITE,null);
        GreenfootImage upgradeLabel = new GreenfootImage(("Upgrades to:"),23,Color.WHITE,null);
        GreenfootImage information = new GreenfootImage(description,20,Color.WHITE,null);
        GreenfootImage nextTowerName = new GreenfootImage((""),25,Color.WHITE,null);
        GreenfootImage nextTower = new GreenfootImage("blank.png");
        //checks which type of tower the player is clicking on and changes next tower name to the next upgrade for that tower
        if (type.equals("arrow"))
        {
            nextTowerName = new GreenfootImage(("Arrow Tower Lv.2"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("arrowtowerlv2button.png");
        }
        else if (type.equals("arrowlv2"))
        {
            nextTowerName = new GreenfootImage(("Arrow Tower Lv.3"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("arrowtowerlv3button.png");
        }
        else if (type.equals("arrowlv3"))
        {
            nextTowerName = new GreenfootImage(("Arrow Tower Lv.4"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("arrowtowerlv4button.png");
        }
        else if (type.equals("arrowlv4"))
        {
            nextTowerName = new GreenfootImage(("Arrow Tower Lv.5"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("arrowtowerlv5button.png");
        }
        else if (type.equals("laser"))
        {
            nextTowerName = new GreenfootImage(("Laser Tower Lv.2"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("lasertowerlv2button.png");
        }
        else if (type.equals("laserlv2"))
        {
            nextTowerName = new GreenfootImage(("Laser Tower Lv.3"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("lasertowerlv3button.png");
        }
        else if (type.equals("laserlv3"))
        {
            nextTowerName = new GreenfootImage(("Laser Tower Lv.4"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("lasertowerlv4button.png");
        }
        else if (type.equals("laserlv4"))
        {
            nextTowerName = new GreenfootImage(("Laser Tower Lv.5"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("lasertowerlv5button.png");
        }
        else if (type.equals("rocket"))
        {
            nextTowerName = new GreenfootImage(("Rocket Tower Lv.2"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("rockettowerlv2button.png");
        }
        else if (type.equals("rocketlv2"))
        {
            nextTowerName = new GreenfootImage(("Rocket Tower Lv.3"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("rockettowerlv3button.png");
        }
        else if (type.equals("rocketlv3"))
        {
            nextTowerName = new GreenfootImage(("Rocket Tower Lv.4"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("rockettowerlv4button.png");
        }
        else if (type.equals("rocketlv4"))
        {
            nextTowerName = new GreenfootImage(("Rocket Tower Lv.5"),20,Color.WHITE,null);
            nextTower = new GreenfootImage("rockettowerlv5button.png");
        }

        else
        {
            //if there is no tower specified then these just have an empty space
            nextTowerName = new GreenfootImage((""),23,Color.WHITE,null);
            upgradeLabel = new GreenfootImage((""),23,Color.WHITE,null);
        }
        //draws each image
        panel.drawImage(bg,600,0);
        panel.drawImage(towerLabel,620,170);
        panel.drawImage(upgradeLabel,610,305);
        panel.drawImage(nextTowerName,675,355);
        panel.drawImage(infoLevel,620,30);
        panel.drawImage(infoMoney,620,50);
        panel.drawImage(infoScore,620,10);
        panel.drawImage(infoLives,620,70);
        panel.drawImage(information,620,400);
        panel.drawImage(nextTower,620,340);
        //updates the panel
        setImage(panel);
    }
}
