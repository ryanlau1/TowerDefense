import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the water tower is a intermediate tower . It is one of the final forms of the arrow tower and can only be
 * built from an arrow tower lv 5.
 * 
 * @author Natalie Lee, Ahsen Husain
 * @version Jan 2014
 */
public class WaterTower extends Towers
{
    private int counter=0;
    /**
     * constructor for the water tower
     * 
     * @param ID the ID of this tower
     */
    public WaterTower(int ID)
    {
        this.ID = ID;

        this.range = 130;
        this.name = "water";
        this.damage = 100;
        this.info = "last upgrade";
        this.cost = 170;
        this.type = "water";

    }

    /**
     * Act - do whatever the NormalTower wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
                //prevents the tower from shooting too quickly
        counter++;
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        myWorld m = (myWorld)getWorld();
        MouseInfo mouse = Greenfoot.getMouseInfo();
        //checks the mouse
        if (Greenfoot.mouseClicked(this))
        {
            //if this tower is clicked it will give the player the option to sell the tower
            m.infoHold(type,ID, info,level,name);
            m.createTowerOptionButton("sell",this.getX(),this.getY(),type);
            i.update(name,info);
        }

                //every 30 acts the tower will check for a target
        if (counter == 20)
        {
            counter = 0;
            checkTarget(type);
        }    
    } 
}
