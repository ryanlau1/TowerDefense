import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the earth tower button lets the player build a earth tower
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class EarthTowerButton extends Buttons
{
    /**
     * the constructor for the earth tower button
     */
    public EarthTowerButton()
    {
        image = new GreenfootImage("earthtowerbutton.png");
        setImage(image);
    }

    /**
     * Act - do whatever the EarthTowerButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        myWorld m = (myWorld)getWorld();
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        //checks for the mouse
        if (Greenfoot.mouseMoved(this))
        {
            //updates info
            updateImage("earthtowerbutton");
            i.update("Damage:70 \nRange:150 \nCost: $230 \nSpeed: Slow");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("earthtowerbutton");
        }
        else if (Greenfoot.mouseClicked(this))
        {         
            //removes the previous tower if the player can build this tower
            if (m.getMoney() >=230)
            {
                m.removeTower();
            }
            m.createTower("earth");

        }
    }    
}
