import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The metal class is a subclass of the bullet class. Its speed is fast and is a type of elemental 
 * bullet. It is only used by the metal towers.
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class Metal extends Bullet
{
   
/**
     * the constructor for the metal class
     * 
     * @param t the mob that this bullet is aiming at
     */
    public Metal(Actor t,int dmg)
    {
        damage = dmg;
        this.target = t;
        this.speed = 50;
                this.type = "metal";
        s = new GreenfootSound ("metal.wav");
    }

    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //plays the sound effect
        s.play();
        //moves the bullet
        move(speed);
        //checks if the bullet is at the worlds edge
        atWorldEdge();

    }

    /**
     * overrides the addedToWorld method in the actor super class and makes sure that as the bullet spawns it
     * turns towards the target
     * 
     * @param w gets the world
     */
    public void addedToWorld (World w)
    {
        turnTowards(target.getX(),target.getY());
    }
}
