import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the fire tower is one of the slowest shooting towers but is very strong. It is one of the final forms of the 
 * rocket tower and can only be built from a rocket tower lv 5.
 * 
 * @author Natalie Lee, Ahsen Husain
 * @version Jan 2014
 */
public class FireTower extends Towers
{
    private int counter=0;
        /**
     * constructor for the fire tower
     * 
     * @param ID the ID of this tower
     */
    public FireTower(int ID)
    {
        this.ID = ID;

        this.range = 200;
        this.name = "fire";
        this.damage = 150;
        this.info = "last upgrade";
        this.cost = 200;
        this.type = "fire";

    }

    /**
     * Act - do whatever the NormalTower wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
                //prevents the tower from shooting too quickly
        counter++;
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        myWorld m = (myWorld)getWorld();
        MouseInfo mouse = Greenfoot.getMouseInfo();
        //checks the mouse
        if (Greenfoot.mouseClicked(this))
        {
            //if this tower is clicked it will give the player the option to sell the tower
            m.infoHold(type,ID, info,level, name);
            m.createTowerOptionButton("sell",this.getX(),this.getY(),type);
            i.update(name,info);
        }

        
        //every 30 acts the tower will check for a target
        if (counter == 30)
        {
            counter = 0;
            checkTarget(type);
        }    
    }

}