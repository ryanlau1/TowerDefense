import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The instructions page is a world that lets the user go through different pages and learn how to
 * play the RAAYN tower defense game.
 * 
 * @author Amanda Mak
 * @version (a version number or a date)
 */
public class InstructionsPage extends World
{
    //Declaring variables for the pages
    private GreenfootImage[] page = new GreenfootImage[3];
    //Integer to keep track on which page they are on, and will be used to check if clicking next or
    //back will change the page to the title screen or the game screen
    private int n = 0;
    private BackButton back = new BackButton();
    private NextButton next = new NextButton();
    private StartButton start = new StartButton();
    /**
     * Constructor for objects of class Instructions.
     */
    public InstructionsPage()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
    }
    /**
     * Adds objects to the world
     */
    private void prepare()
    {
        addObject(back, 110, 550);
        addObject (next, 690, 550);
        addObject (start, 400, 550); 
    }
    /**
     * Act method that runs through the code every act
     */
    public void act()
    {
        turnPages();
    }
    /**
     * Assigns the image names to the array page[]
     */
    private void assignImages()
    {
        //assigns the images to the page array. Instruction-names go as follows
        /**
         * Instructions0.png
         * Instructions1.png
         * Instructions2.png
         */
        for (int i = 0; i < page.length; i++)
        {
            page[i] = new GreenfootImage("Instructions" + i + ".png");
        }
    }
    /**
     * Changes the instructions page, and will also go to the title page or start the game.
     */
    private void turnPages()
    {
        assignImages();
        //If the user clicks the 'back' button and n is at 0, it will go back to the Title screen
        if (Greenfoot.mouseClicked(back) && n == 0)
        {
            Greenfoot.setWorld(new Title());
        }
        //If the user clicks the 'next' button and n is smaller or equal to 2, it will change the page
        //and then increase n by 1
        if (Greenfoot.mouseClicked(next) && n < 2)
        {
            n+=1;    
            setBackground(page[n]);    
            
        }
        //If the user clicks the 'back' button and n is larger than or equal to 2, it will change
        //the page to the one before, and decrease n
        if (Greenfoot.mouseClicked(back) && n >=1)
        {
            n-=1;
            setBackground(page[n]);
        }
        //If n is equal to 3 and the user clicks 'next', it will start the game.
        if (Greenfoot.mouseClicked(next) && n == 3)
        {
            Greenfoot.setWorld(new myWorld());
        }
        //if the user clicks the 'start' button, the game begins.
        if (Greenfoot.mouseClicked(start))
        {
            Greenfoot.setWorld(new myWorld());
        }
        /**
         * Check if the back/next button is pressed and then do
         * num+ if its 'next', then set the image for page[num]
         * num- if its 'back', then set the image for page[num]
         */
        
    }
}
