import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the rocket tower button creates a rocket tower on the field
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class RocketTowerButton extends Buttons
{
    /**
     * the constructor for the rocket tower button
     */
    public RocketTowerButton()
    {
        image = new GreenfootImage("rockettowerbutton.png");
        setImage(image);
    }

    /**
     * Act - do whatever the RocketTowerButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        myWorld m = (myWorld)getWorld();
        //checks for the mouse
        if (Greenfoot.mouseMoved(this))
        {
            //updates information
            updateImage("rockettowerbutton");
            i.update("Rocket tower \nDamage:10 \nRange:80 \nCost: $30 \nSpeed: Slow");
        }
        else if (Greenfoot.mouseClicked(this))
        {
            //creates a rocket tower
            m.createTower("rocket");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("rockettowerbutton");
        }
    }    
}