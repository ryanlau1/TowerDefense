import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the laser tower button lets the player make a laser tower
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class LaserTowerButton extends Buttons
{
    /**
     * constructor fo the laser tower button 
     */
    public LaserTowerButton()
    {
        image = new GreenfootImage("lasertowerbutton.png");
        setImage(image);
    }

    /**
     * Act - do whatever the LaserTowerButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {

        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        myWorld m = (myWorld)getWorld();
        //checks for the mouse
        if (Greenfoot.mouseMoved(this))
        {
            //updates information
            updateImage("lasertowerbutton");
            i.update("Laser tower \nDamage:1 \nRange:100 \nCost: $20 \nSpeed:fast");
        }
        else if (Greenfoot.mouseClicked(this))
        {
            //makes a laser tower
            m.createTower("laser");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("lasertowerbutton");
        }
    }    
}