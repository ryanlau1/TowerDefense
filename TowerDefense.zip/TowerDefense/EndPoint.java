import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * EndPoint is a subclass of turnPoint. It is the cell in which the mobs will be removed and the lives for the 
 * gamer is substracted by one. 
 * 
 * @Yao Lu, Amanda Mak, Natalie Lee
 * @version 1
 */
public class EndPoint extends turnPoint
{

    private EndPoint next;
    /**
     * Act - do whatever the EndPoint wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //use the current turn point as a placeholder for the next
        if (next == null){
            next = this;
        }

        //if the world clicks this object then clear the temporary information holders
        myWorld m = (myWorld)getWorld();
        if (Greenfoot.mouseClicked(this))
        {
            m.clearTemp();
        }
    }     

}
