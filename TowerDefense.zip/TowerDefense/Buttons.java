import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The buttons class is the super class for various button subclasses. Its basic function is to allow the user
 * to interact with the game 
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public abstract class Buttons extends Actor
{
    protected GreenfootImage image;
    /**
     * Act - do whatever the Buttons wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }  
    
    /**
     * changes the image of the button id it was hovered over
     * 
     * @param name the name of the new image file
     */
    protected void updateImage(String name)
    {
        image = new GreenfootImage(name+"1.png");
        setImage(image);
    }
    
    /**
     * reverts the changed image back to the original image
     * 
     * @param name the name of the original image file
     */
    protected void revertImage(String name)
    {
        image = new GreenfootImage(name+".png");
        setImage(image);
    }
    
}
