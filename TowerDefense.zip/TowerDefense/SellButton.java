import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * If this button was clicked then the user sells the tower that was selected
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class SellButton extends Buttons
{
    /**
     * the constructor for the sellbutton class
     */
     public SellButton()
   {
     image = new GreenfootImage("sell.png");
     setImage(image);
   }

    /**
     * Act - do whatever the SellButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        myWorld m = (myWorld)getWorld();
        //checks for the mouse
        if (Greenfoot.mouseClicked(this))
        {
            m.deleteTower();
        }
        else if (Greenfoot.mouseMoved(this))
        {
            updateImage("sell");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("sell");
        }
    }    
    
}
