import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the next button is found in the instructions world and if clicked on it will turn to the next instructions page
 * 
 * @author Amanda Mak, Natalie Lee
 * @version Jan 2014
 */
public class NextButton extends Buttons
{
    /**
     * Act - do whatever the NextButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        //checks for the mouse and changes the image
        if (Greenfoot.mouseMoved(this))
        {
            updateImage("Next");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("Next");
        }
    }    
}
