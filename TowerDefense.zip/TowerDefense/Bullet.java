import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Bullet is a superclass that contains several subclasses of bullets
 * 
 * The basic function of each bullet is to be shot at a predetermined target and deal damage to it
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public abstract class Bullet extends Actor
{
    protected int damage;
    protected GreenfootSound s; 
    protected  Actor target;
    protected int speed;
    protected String type;

    /**
     * gets the bullets damage
     * 
     * @return int  The damage of the bullet
     */
    protected int getDamage()
    {
        return damage;
    }
    
    /**
     * gets the type of bullet
     * 
     * @return String The type of bullet (ie. elemental bullet)
     */
    protected String getType()
    {
        return type;
    }

    /**
     * stops the music from playing
     */
    protected void stopPlay(){
        s.stop();
    }

    /**
     * if the bullet reaches the end of the map then remove it
     */
    protected void atWorldEdge()
    {
        myWorld m = (myWorld)getWorld();
        if (this.getX()>=599|| this.getX()<=1 || this.getY()>=599||this.getY()<=1)
        {
            m.removeObject(this);
        }
    }
}