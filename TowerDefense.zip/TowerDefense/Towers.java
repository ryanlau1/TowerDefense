import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
/**
 * The tower class is the superclass for various tower subclasses. the main function of the tower is to help defend your castle from enemys that are trying to 
 * destroy it. The tower class follows a moeny system, ad can be upgraded 6 times, gaining damage and range to defeat the enemy
 * 
 * @author Natalie Lee, Ahsen Husain
 * @version Jan 2014
 */
public abstract class Towers extends Actor
{
    protected int ID;
    protected int level;
    protected Actor target;
    protected ArrayList<Actor> targetsNearby = new ArrayList<Actor>();
    protected int damage;
    protected int closestTargetDistance;
    protected int range;
    protected String info;
    protected String name;
    protected int cost;
    protected String type;

    /**
     * Act - do whatever the Towers wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    

    /**
     * gets the ID of the tower
     * 
     * @return int The ID of the tower
     */
    protected int getID()
    {
        return ID;
    }

    /**
     * sets the level of the tower
     * 
     * @param level The new level of the tower
     */
    protected void setLevel(int level)
    {
        this.level = level;
    }

    /**
     * sets the range of the tower
     * 
     * @param range The new range of the tower
     */
    protected void setRange(int range)
    {
        this.range = range;
    }

    /**
     * gets the range of the tower
     * 
     * @return int The range of the tower
     */
    protected int getRange()
    {
        return range;
    }

    /**
     * sets the name of the tower
     * 
     * @param int The new name of the tower
     */
    protected void setName(String name)
    {
        this.name = name;
    }

        /**
     * gets the name of the tower
     * 
     * @return String The name of the tower
     */
    protected String getName()
    {
        return name;
    }

    /**
     * gets the cost of the tower
     * 
     * @return int The cost of the tower
     */
    protected int getCost()
    {
        return cost;
    }

    /**
     * sets the ID of the tower
     * 
     * @param int The new cost of the tower
     */
    protected void setCost(int cost)
    {
        this.cost = cost;
    }

    /**
     * gets the towers damage
     * 
     * @return int The towers damage
     */
    protected int getDamage()
    {
        return damage;
    }

    /**
     * sets the damage of the tower
     * 
     * @param dmg The new damage of the tower
     */
    protected void setDamage(int dmg)
    {
        this.damage = dmg;
    }

    /**
     * sets the towers infomation
     * 
     * @param int The towers infomation
     */
    protected void setInfo(String info)
    {
        this.info = info;
    }

    /**
     * check for the closest target and creates a bullet to shoot at it
     * credit to Mr.Cohen
     */
    protected void checkTarget (String tower)
    {
        target = null;
        myWorld m = (myWorld)getWorld();
        targetsNearby = (ArrayList)getObjectsInRange (range, Mobs.class);
        if (targetsNearby.size() > 0)
        {
            target = (Mobs)targetsNearby.get(0);
            closestTargetDistance = (int)m.getDistance(target,this);
            for (Object o : targetsNearby)
            {
                //checks each target and find the one that is closest
                Mobs e = (Mobs)o;
                if (m.getDistance(e,this) < closestTargetDistance)
                    target = e;
            }

            m.shoot(this.getX(),this.getY(),tower, target, this.damage);

        }
    }

}
