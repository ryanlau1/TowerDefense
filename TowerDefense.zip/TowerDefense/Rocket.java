import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The laser class is a subclass of the bullet class. It is the slowest moving normal bullet and is only
 * used by the rocket towers and its upgrades.
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class Rocket extends Bullet
{

    /**
     * the constructor for the rocket class
     * 
     * @param t the mob that this bullet is aiming at
     */
    public Rocket(Actor t, int dmg)
    {
        damage = dmg;
        target = t;
        this.speed = 5;
        this.type = "rocket";
        s = new GreenfootSound ("rocket.wav");
        s.setVolume(75);
    }

    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //plays the sound effect
        s.play();
        //moves the bullet
        move(speed);
        //checks if the bullet is at the worlds edge
        atWorldEdge();

    }

    /**
     * overrides the addedToWorld method in the actor super class and makes sure that as the bullet spawns it
     * turns towards the target
     * 
     * @param w gets the world
     */
    public void addedToWorld (World w)
    {
        turnTowards(target.getX(),target.getY());
    }
}
