import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Cells that the player can build their towers on
 * 
 * @author Natalie Lee & Amanda Mak
 * @version Jan 2014
 */
public class BuildableCell extends Actor
{

    /**
     * Act - do whatever the buildableCell wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        myWorld m = (myWorld)getWorld();
        // Add your action code here.
        if (Greenfoot.mouseClicked(this))
        {
            m.clearTemp();
            m.createTowerOptionButton("build",this.getX(),this.getY(),"");
            i.update();
            setImage("tile1.png");

        }
        else if (Greenfoot.mouseMoved(this))
        {
            setImage("tile1.png");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            setImage("tile.png");
        }

    }    
}
