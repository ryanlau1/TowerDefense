import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Changes the world from the Title to the Highscores page
 * 
 * @author Amanda Mak and Natalie Lee 
 * @version Jan 2014
 */
public class HighScoresButton extends Buttons
{
    /**
     * The constructor for the HighScoresButton class
     */
    public HighScoresButton()
    {
        image = new GreenfootImage("HighScoresButton.png");
        setImage(image);
    }

    /**
     * Act - do whatever the HighScoresButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        if (Greenfoot.mouseMoved(this))
        {
            updateImage("HighScoresButton");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("HighScoresButton");
        }
        if (Greenfoot.mouseClicked(this))
        {
            Greenfoot.setWorld(new HighScoresPage());
        }
    }   
}
