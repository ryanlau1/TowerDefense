import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Cells that the mobs can walk on, towers cannot be built on these cells.
 * 
 * @author Natalie Lee & Amanda Mak
 * @version Jan 2014
 */
public class PathCell extends Actor
{
    /**
     * Act - do whatever the PathCell wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        myWorld m = (myWorld)getWorld();
        // Add your action code here.
        if (Greenfoot.mouseClicked(this))
        {
            m.clearTemp();
        }
    }    
}
