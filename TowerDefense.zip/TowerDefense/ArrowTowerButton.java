import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the arrow tower button lets the player build an arrow tower
 * 
 * @author Natalie Lee 
 * @version Jan 2014
 */
public class ArrowTowerButton extends Buttons
{
    /**
     * the constructor for the arrow tower button
     */
    public ArrowTowerButton()
    {
        image = new GreenfootImage("arrowtowerbutton.png");
        setImage(image);
    }
    
    /**
     * Act - do whatever the ArrowTowerButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        myWorld m = (myWorld)getWorld();
        //checks for he mouse
        if (Greenfoot.mouseMoved(this))
        {
            //update info
            updateImage("arrowtowerbutton");
            i.update("Arrow tower \nDamage:5 \nRange:100 \nCost: $20 \nSpeed: Normal");
        }
        else if (Greenfoot.mouseClicked(this))
        {
            //creates an arrow tower
            m.createTower("arrow");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("arrowtowerbutton");
        }
    }    
    
    
}
