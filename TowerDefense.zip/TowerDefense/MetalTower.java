import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the metal tower is the quickest shooting tower but it is very weak. It is the final form of the laser tower 
 * and can only be built if the player had built a laser tower lv 5.
 * 
 * @author Natalie Lee, Ahsen Husain
 * @version Jan 2014
 */
public class MetalTower extends Towers
{
    private int counter=0;
    /**
     * constructor for the metal tower
     * 
     * @param ID the ID of this tower
     */
    public MetalTower(int ID)
    {
        this.ID = ID;

        this.range = 150;
        this.name = "metal";
        this.damage = 150;
        this.info = "last upgrade";
        this.cost = 150;
        this.type = "metal";

    }

    /**
     * Act - do whatever the NormalTower wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
                //prevents the tower from shooting too quickly
        counter++;
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        myWorld m = (myWorld)getWorld();
        MouseInfo mouse = Greenfoot.getMouseInfo();
        // Add your action code here.
        if (Greenfoot.mouseClicked(this))
        {
            //if this tower is clicked it will give the player the option to sell the tower
            m.infoHold(type,ID, info,level,name);
            m.createTowerOptionButton("sell",this.getX(),this.getY(),type);
            i.update(name,info);
        }

                //every 5 acts the tower will check for a target
        if (counter == 5)
        {
            counter = 0;
            checkTarget(type);
        }    
    }
}
