import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * If this button was clicked then the wave of mobs starts and this button disappears for the rest of the game
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class StartWaveButton extends Buttons
{
        /**
     * the constructor for the startwavebutton class
     */
    public StartWaveButton()
    {
        image = new GreenfootImage("startwave.png");
    }
    /**
     * Act - do whatever the StartWave wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        myWorld m = (myWorld)getWorld();
        //checks for the mouse
        if (Greenfoot.mouseMoved(this))
        {
            updateImage("startwave");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("startwave");
        }
        else if (Greenfoot.mouseClicked(this))
        {
            m.startWaves();
            m.deleteStartButton();
        }
    }    
}
