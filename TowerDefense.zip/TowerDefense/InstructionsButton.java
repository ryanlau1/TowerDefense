import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the Instructions button is found on the title page and lets the user look at the instructions
 * 
 * @author Amanda Mak & Natalie Lee
 * @version Jan 2014
 */
public class InstructionsButton extends Buttons
{
    /**
     * the constructor for the instructions button
     */
    public InstructionsButton()
    {
        image = new GreenfootImage("InstructionsButton.png");
        setImage(image);
    }
    
    /**
     * Act - do whatever the InstructionsButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        toInstructions();
    }    
    /**
     * checks for the mouse 
     */
    private void toInstructions()
    {
        if (Greenfoot.mouseClicked(this))
        {
            //sets to the new world
            Greenfoot.setWorld(new InstructionsPage());
        }
        else if (Greenfoot.mouseMoved(this))
        {
            updateImage("InstructionsButton");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("InstructionsButton");
        }
    }
}
