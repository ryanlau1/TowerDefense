import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
/**
 * Writes and saves to a file
 * Old code from file writing assignment
 * 
 * @author Amanda Mak
 * @version Jan 2014
 */
public class WriteFile
{
    private String path;
    private boolean append_to_file = false;
    /**
     * Act - do whatever the WriteFile wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }   
    public WriteFile(String file_path)
    {
        //name & location of file
        path = file_path;
    }
    public WriteFile( String file_path , boolean append_value ) 
    {
        path = file_path;
        append_to_file = append_value;
    }
    //Handles file-writing errors
    public void writeToFile(String textLine)throws IOException
    {
        FileWriter write = new FileWriter( path , append_to_file);
        PrintWriter print_line = new PrintWriter(write);
        // %n means a newline. using \n only works on certain OS's
        //printf(String format, .. PrintWriter
        print_line.printf( "%s" + "%n" , textLine);
        //closes text file
        print_line.close();
    }
}
