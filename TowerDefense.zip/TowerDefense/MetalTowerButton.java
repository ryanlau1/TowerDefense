import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the metal tower button creates a metal tower
 * 
 * @author Natalie Lee
 * @version Jan 2014
 */
public class MetalTowerButton extends Buttons
{
    /**
     * the constructor for the metal tower button
     */
    public MetalTowerButton()
    {
        image = new GreenfootImage("metaltowerbutton.png");
        setImage(image);
    }

    /**
     * Act - do whatever the MetalTowerButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        myWorld m = (myWorld)getWorld();
        infoPanel i= (infoPanel)getOneIntersectingObject(infoPanel.class);
        //checks for the mouse
        if (Greenfoot.mouseMoved(this))
        {
            //updates information
            updateImage("metaltowerbutton");
            i.update("Damage:30 \nRange:150 \nCost: $150 \nSpeed: Fast");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("metaltowerbutton");
        }
        else if (Greenfoot.mouseClicked(this))
        {
            //removesthe previous tower if the player can build this tower
            if (m.getMoney() >=150)
            {
                m.removeTower();
            }
            m.createTower("metal");

        }
    }    
}
