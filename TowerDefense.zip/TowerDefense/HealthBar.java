import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.Font;
/**
 * HealthBar is a Greenfoot Actor that displays the health points in a virtualized way. 
 * The color of the bar can change according to the remaining health points.
 * The health points recover slowly by itself.
 * 
 * @author Yao Lu
 * @version Sept 26, 2013
 */
public class HealthBar extends Actor
{
    private GreenfootImage frame; // the image of the background of the health bar
    private GreenfootImage lable; // the words on the bar, can be a notice or a number showing  how many health points are remained out of the total
    private GreenfootImage colorbar; // the image of the colorful part of the bar
    private int max; //full health point
    private int fontSize;
    private int value;//current health point
    private int target;// when health point increases/decreases,the final value of the change
    private int counter;//counts how many times the code has run for, help adding health points gradually
    private boolean ifDied;//stores if the user has died
    private int change;// when health point increases/decreases,the amount of the change. 
                       //This variable makes sure the number doesn't always have to increase by one, which might take too long.

    /**
     * Interacts with the user, changing the health points and displays the result.
     * 
     */
    public void act() 
    {
       
        //responds to incValue() and decValue() methods called by the world
        value = target;        
        update();
        
        //If the method has run for 10 times, the health point recovers by a "change" unit.
        //if(counter== 10){
        //    if ((target+change)<=max)
        //        target = target + change;
        //    else
        //        target = max;
        //    counter = 0;
        //}
        
        //if(ifDied == true){
        //    update("You died.");
        //}        
    }    
    
    /**
     * Assigns values for private variables according to the parameters and 
     * draws the backgroud frame for the health bar.
     * 
     * @param width the width of the health bar
     * @param height the height of the health bar
     * @param font the font size of the lables on the healthbar
     * @param maximum the full health point
     * 
     */
    public HealthBar(int width, int height,int font,int maximum){
        value = maximum; //no specific requirment for current health point, assumes the health is full
        max = maximum;
        change  = (int)Math.round(max/100); // the amount changed each time is aprroximately 1/100 of the maximum value
        fontSize = font;
        target = value;
        counter = 0;
        ifDied = false;
        
        // draws the gray background frame for the health bar, ovals are used to create a better-looking bar with round ends
        frame = new GreenfootImage(width, height);
        frame.setColor(Color.gray);
        frame.fillOval(0, 0, width/5, height); // fills an oval with a width of 1/5 of the bar width 
        frame.fillRect(width/10, 0, width/5*4, height); // starting at the middle of the oval, draws a rectangle
        frame.fillOval(width/5*4, 0, width/5, height); // starting at the end of the rectangle, draws another oval
        setImage(frame);   
        
        colorbar = new GreenfootImage(width,height); //creates the image for coloured by, does not define it yet
        
        update("Start.");//set up with a notice instead of the bar.
    }
    
    /**
     * Assigns values for variables according to the parameters and 
     * draws the backgroud frame for the health bar.
     * 
     * @param width the width of the health bar
     * @param height the height of the health bar
     * @param font the font size of the lables on the healthbar
     * @param maximum the full health point
     * @param currentValue the starting health point
     * 
     */
    public HealthBar (int width, int height, int font,  int maximum,int currentValue){        
        max = maximum;
        value = currentValue; //if currentValue is included in the signature, a specific health point is assigned.
        change = (int)Math.round(max/100);
        fontSize = font;
        target = value;
        counter = 0;
        ifDied = false;
        
        // draw the gray background frame for the health bar
        frame = new GreenfootImage(width, height);
        frame.setColor(Color.gray);
        frame.fillOval(0, 0, width/5, height);
        frame.fillRect(width/10, 0, width/5*4, height);
        frame.fillOval(width/5*4, 0, width/5, height);
        setImage(frame); 
        
        colorbar = new GreenfootImage(width,height);
          
        update("Start.");
    }
 
    /**
     * Updates the bar to a notice
     * @param notice Announcement to the users at the beginning and the end of opeartion
     */
    public void update(String notice){        
        GreenfootImage image = new GreenfootImage(frame);
        lable = new GreenfootImage(notice, fontSize, Color.white, null);
        image.drawImage(lable,(image.getWidth()-lable.getWidth())/2,(image.getHeight()-lable.getHeight())/2); 
        //in the brackers are some math to make sure the lable appears in the middle of the bar
        setImage(image);  
    }
    
    /**
     * Updates the bar, including changing the color and size of the bar, as well as health points
     */
    public void update(int x, int y){
        setLocation(x,y);
        // an new image is created to combine the lable and the color bar together later
        GreenfootImage image = new GreenfootImage(frame);
        double ratio = (double)value/(double)max;
        int frameWidth = frame.getWidth();
        int frameHeight = frame.getHeight();
        int barWidth = (int)Math.round(ratio*frameWidth);  // the width of the coloured part is calculated according to the ration between current hp and the maximun hp      
        // draws a color bar with the same size as the frame
        colorbar.clear();
        colorbar.setColor(setColor());// setColor() method is called to decided the color of the bar
        colorbar.fillOval(0, 0, frameWidth/5, frameHeight); 
        colorbar.fillRect(frameWidth/10, 0, frameWidth/5*4, frameHeight);
        colorbar.fillOval(frameWidth/5*4, 0, frameWidth/5, frameHeight);
        if(barWidth>0){ 
            GreenfootImage part = new GreenfootImage(barWidth, frameHeight); // another image is set with the bar width, therefore cutting the whole color bar to its right size
            part.drawImage(colorbar, 0, 0);                        
            image.drawImage(part, 0, 0);           
        }
        lable = new GreenfootImage(""+value+"/"+max, fontSize, Color.black, null);
        image.drawImage(lable,(image.getWidth()-lable.getWidth())/2,(image.getHeight()-lable.getHeight())/2);
        setImage(image);             
    }
    
    /**
     * Updates the bar, including changing the color and size of the bar, as well as health points
     */
    public void update(){
        // an new image is created to combine the lable and the color bar together later
        GreenfootImage image = new GreenfootImage(frame);
        double ratio = (double)value/(double)max;
        int frameWidth = frame.getWidth();
        int frameHeight = frame.getHeight();
        int barWidth = (int)Math.round(ratio*frameWidth);  // the width of the coloured part is calculated according to the ration between current hp and the maximun hp      
        // draws a color bar with the same size as the frame
        colorbar.clear();
        colorbar.setColor(setColor());// setColor() method is called to decided the color of the bar
        colorbar.fillOval(0, 0, frameWidth/5, frameHeight); 
        colorbar.fillRect(frameWidth/10, 0, frameWidth/5*4, frameHeight);
        colorbar.fillOval(frameWidth/5*4, 0, frameWidth/5, frameHeight);
        if(barWidth>0){ 
            GreenfootImage part = new GreenfootImage(barWidth, frameHeight); // another image is set with the bar width, therefore cutting the whole color bar to its right size
            part.drawImage(colorbar, 0, 0);                        
            image.drawImage(part, 0, 0);           
        }
        lable = new GreenfootImage(""+value+"/"+max, fontSize, Color.black, null);
        image.drawImage(lable,(image.getWidth()-lable.getWidth())/2,(image.getHeight()-lable.getHeight())/2);
        setImage(image);             
    }
        
    /**
     * Changes the color of health bar from red to green gradually as the value increases.
     */
    public Color setColor(){
        GreenfootImage image = new GreenfootImage(frame);//add an image here to get the color I want
        double ratio = (double)value/(double)max; //a varibale to keep track of the ratio between current value and the max value
        if( ratio <= 0.5){ 
            frame.setColor(new Color(253,(int)(500*ratio),2));//set the color according to the ratio
            return frame.getColor();
        } 
        if (ratio> 0.5 && ratio<1){
            frame.setColor(new Color((int)(500*(1-ratio)),253,2));
            return frame.getColor();    
        }
        return Color.green;
    }
    
    /**
     * Decreases the health points by 1/5 of the full health.
     */
    public void decValue(){
        if( (value-max/5) >= 0){ // prevent hp from being negative
            target = value - max/5;
        }else {
            target = 0;
        }
    }
    
    /**
     * Decreases the health points by a certain amount
     */
    public void decValue(int i){
        if( (value-i) >= 0){ // prevent hp from being negative
            target = value - i;
        }else {
            target = 0;
        }
    }
    
    /**
     * Increases the health points by 1/5 of the full health.
     */
    public void incValue(){
        if ((value + max/5)<= max){ //prevent hp from exceeding max
            target = value + max/5;
        }else{
            target = max;
        }
    }
    
    /**
     * Sets the boolean value ifDied to true.
     */
    public void die(){
        ifDied = true;
    }
}

