import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * the start button is found in the title world and the instructions world and lets the player start the game
 * 
 * @author Amanda Mak, Natalie Lee
 * @version Jan 2014
 */
public class StartButton extends Buttons
{
    /**
     * the constructor for the start button class
     */
    public StartButton()
    {
        
        image = new GreenfootImage("StartButton.png");
        setImage(image);
    }
    
    /**
     * Act - do whatever the StartButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //checks for the mouse
        if (Greenfoot.mouseMoved(this))
        {
            updateImage("StartButton");
        }
        else if (Greenfoot.mouseMoved(null))
        {
            revertImage("StartButton");
        }
        startGame();
    }    
    
    /**
     * sets a new world if the button is pressed
     */
    private void startGame()
    {
        if(Greenfoot.mouseClicked(this))
        {
            Title a = (Title)getWorld();
            Greenfoot.setWorld(new myWorld());
        }
    }
}
